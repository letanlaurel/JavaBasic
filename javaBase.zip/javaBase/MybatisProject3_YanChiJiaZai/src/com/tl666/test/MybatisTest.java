package com.tl666.test;

import java.io.IOException;
import java.util.List;

import com.tl666.dao.UserDao;
import com.tl666.domain.Student1;

public class MybatisTest {
	/**
	 * 延迟加载 提高数据库性能
	 */
	private static UserDao ud = new UserDao();
	public static void main(String[] args) throws IOException {
		List<Student1> list = ud.getAllStudents();
		for (Student1 student : list) {
			System.out.println(student.getName()+"==="+student.getTeacher().getName());
		}
	}
	public static int test1() throws IOException {
		return 0;
	}
}
