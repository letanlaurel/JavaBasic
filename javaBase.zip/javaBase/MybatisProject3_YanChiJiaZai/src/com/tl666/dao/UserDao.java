package com.tl666.dao;

import java.io.IOException;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.tl666.Utils.MybatisUtil;
import com.tl666.domain.Student1;

public class UserDao {
	public List<Student1> getAllStudents() throws IOException {
		SqlSession session = MybatisUtil.getSqlSession();
		List<Student1> list = session.selectList("com.tl666.domain.StudentMapper.getAllStudent");
		session.close();
		return list;
	}

}
