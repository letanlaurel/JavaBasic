import java.util.Comparator;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class SetDemo {
	static Set<Student> set = null;
	public SetDemo() {
		set = new TreeSet<>(new compareStudent());
	}
	/**
	 * 添加学生到set集合
	 * @param stu
	 */
	public void Add(Student stu) {
		if(stu != null)
		set.add(stu);
	}
	/**
	 * 打印学生信息
	 */
	public void show() {
		Iterator<Student> st = set.iterator();
		while (st.hasNext()) {
			Student stu = st.next();
			System.out.printf("%s\t%d\t%.2f\t%.2f\t%.2f\t%.2f\t%.2f\n", stu.getId(), stu.getCs(), stu.getChinese(),
					stu.getMath(), stu.getEnglish(), stu.getScore(), stu.getAvg());
		}
	}
}
class compareStudent implements Comparator<Student>{

	@Override
	public int compare(Student o1, Student o2) {
		if (o1.getScore() < o2.getScore())
			return 1;
		else if (o1.getScore() > o2.getScore())
			return -1;
		else if (o1.getChinese() < o2.getChinese())
			return 1;
		else if (o1.getChinese() > o2.getChinese())
			return -1;
		else if (o1.getMath() < o2.getMath())
			return 1;
		else if (o1.getMath() > o2.getMath())
			return -1;
		else if (o1.getEnglish() < o2.getEnglish())
			return 1;
		else if (o1.getEnglish() > o2.getEnglish())
			return -1;
		return 0;
	}

	
	
}
