import javax.swing.JOptionPane;


public class 后宫选妃 {

	/**
	 * @param args
	 */
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String  NameArrays[] = {};
		JOptionPane.showInputDialog(null, "","");
	}

}
