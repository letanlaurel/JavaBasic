
public class Student{// implements Comparable<Student> {
	private String id;
	private int cs;
	private double chinese;
	private double math;
	private double english;
	private double score;
	private double avg;

	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Student(String id, int cs, double chinese, double math, double english) {
		super();
		this.id = id;
		this.chinese = chinese;
		this.math = math;
		this.english = english;
		this.cs = cs;
		setScore(english+math+chinese);
		setAvg((english+math+chinese)/3.0);
	}
	/**
	 *  Ϊ���ܹ�ʹ��collection������Ĭ�ϵķ����������� ʵ����Ҫʵ��comparable�ӿ�
	 * @param o
	 * @return
	 */
//	@Override
//	public int compareTo(Student o) {
//		if(chinese+math+english < o.getChinese()+o.getMath()+o.getEnglish())
//			return 1;
//		if(chinese+math+english > o.getChinese()+o.getMath()+o.getEnglish())
//			return -1;
//		return 0;
//	}

	public int getCs() {
		return cs;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

	public double getAvg() {
		return avg;
	}

	public void setAvg(double avg) {
		this.avg = avg;
	}

	public void setCs(int cs) {
		this.cs = cs;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getChinese() {
		return chinese;
	}

	public void setChinese(double chinese) {
		this.chinese = chinese;
	}

	public double getMath() {
		return math;
	}

	public void setMath(double math) {
		this.math = math;
	}

	public double getEnglish() {
		return english;
	}

	public void setEnglish(double english) {
		this.english = english;
	}

}
