package ExceptionDemo;

public class EPmain {

	public static void main(String[] args) {
		hero h;
		try {
			h = new hero("����",40,-1);
			h.RidM();
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

}
