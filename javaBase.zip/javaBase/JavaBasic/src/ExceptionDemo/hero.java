package ExceptionDemo;
/**
 * Ӣ���� - �����Զ����쳣
 * @author 19760
 *
 */
public class hero {
	private String name;
	private int HP;
	private int exp;
	public hero(String name ,int HP , int exp) throws Exception {
		setName(name);
		setExp(exp);
		setHP(HP);
	}
	public void RidM() throws Exception {
		if(HP>=50) {
			System.out.println(name+"��ǰ����ֵΪ��"+HP);
			System.out.println(name+"���ڿ��ĵ�������");
		}
		else {
			throw new Ridma(HP);
		}
			
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getHP() {
		return HP;
	}
	public void setHP(int hP) {
		HP = hP;
	}
	public int getExp() {
		return exp;
	}
	public void setExp(int exp) throws Exception {
		if(exp>=0) {
		this.exp = exp;
		System.out.println(name+"��ǰ����ֵΪ��"+exp);
		}
		else {
			throw new ExpisnotZero(exp,name);
		}
	}
	
	
}
