import java.util.Map;
import java.util.TreeMap;

public class aafaaaa {
	public static Long getBestTeam(int numbers, int[] abilities, int selectedNum, int distance){
		abilities = new int[] {7,4,7};
		Map<Integer, Integer> map = new TreeMap<>((o1, o2) -> {
			if(o1 > o2)
				return -1;
			if(o1 > o2)
				return 1;
			return 0;
		});
		for (int i = 0; i < abilities.length; i++) {
			map.put(i, abilities[i]);
		}
		System.out.println(map);
		int j = 0;
		long s = 1;
		
		return s;
    }
	public static void main(String[] args) {
		System.out.println(getBestTeam(3, null, 2, 50));
	}

}
