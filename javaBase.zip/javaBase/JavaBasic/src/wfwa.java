
public class wfwa {
		public static void main(String[] args) {
			StringBuffer sb = new StringBuffer();
			sb.append("123456");
			System.out.println(sb.reverse().toString());
			
		}
}
