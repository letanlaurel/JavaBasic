import java.util.Scanner;

public class listText {
	static ListDemo ld = null;
	public static void main(String[] args) {
		IN();
		ld.sort();
		ld.show();
		
	}
	public static void IN() {
		ld = new ListDemo();
		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		String str = input.nextLine();
		for (int i = 0; i < N; i++) {
		    str = input.nextLine();
		    String a[] = str.split(" ");
		    ld.Add(new Student(a[0],Integer.parseInt(a[1].trim()),Double.parseDouble(a[2].trim()),Double.parseDouble(a[3].trim()),Double.parseDouble(a[4].trim())));
		}
		input.close();
	}
}
//4
//0806401001 1 56 64 77
//0806401002 1 75 68 54
//0806401003 1 68 79 76
//0806401004 1 56 57 84