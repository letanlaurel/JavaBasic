import java.util.Scanner;

public class SetTest {
		static SetDemo sd = null;
	public static void main(String[] args) {
		IN();
		sd.show();
	}
	public static void IN() {
		sd = new SetDemo();
		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		String str = input.nextLine();
		for (int i = 0; i < N; i++) {
		    str = input.nextLine();
		    String a[] = str.split(" ");
		    sd.Add(new Student(a[0],Integer.parseInt(a[1].trim()),Double.parseDouble(a[2].trim()),Double.parseDouble(a[3].trim()),Double.parseDouble(a[4].trim())));
		}
		input.close();
	}
}
