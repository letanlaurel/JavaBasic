import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class TimeDemo {

	public static void main(String[] args) {
		Calendar cd = Calendar.getInstance();//单列模式 只能被实例化一次
		
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss:SSS");
			System.out.println(sf.format(cd.getTime()));
		  String  stime = sf.format(cd.getTime());
		 System.out.println(cd.getTimeInMillis()); 
		  try {
			System.out.println(sf.parse(stime).getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		  Date dt = new Date();
		  System.out.println(dt);
	}

}
