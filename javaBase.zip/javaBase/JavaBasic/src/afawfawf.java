import java.util.Arrays;

public class afawfawf {
		public static void main(String[] args) {
			int []a = new int[] {13,1,3,11,5,8,9,2,12,14,6};
			Arrays.sort(a);
			int j = 0;
			StringBuffer sb = new StringBuffer();
			for (int i : a) {
				if(++j != i) {
					sb.append(j);
					j = i;
				}
			}
			System.out.println(sb);
			System.out.println(Integer.parseInt(sb.toString())%11);
		}
		
}
