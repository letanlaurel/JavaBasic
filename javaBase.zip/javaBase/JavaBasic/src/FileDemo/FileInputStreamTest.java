package FileDemo;

import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class FileInputStreamTest {
	private static final String path = ".";
		public static void main(String[] args) throws Exception {
			JFileChooser jf = new JFileChooser(path);
			jf.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
			jf.showOpenDialog(null);
			File file = jf.getSelectedFile();
			if(file == null) {
				JOptionPane.showMessageDialog(null, "你已取消选择");//弹窗提示
				System.exit(0);
			}
		}
}
