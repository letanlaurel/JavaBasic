package FileDemo;

public class ComponentTest {

	public static void main(String[] args) {
		Component cp = new TureComponent();
		ComponentImplA ca = new ComponentImplA(cp);
		ca.read();

	}

}
