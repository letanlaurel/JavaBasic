package FileDemo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class PrintWriteDemo {
	public static final String filepath = "C:/Users/19760/Desktop/MySQL.txt";
	public static final String filepath2 = "E:/JavaStudy/JavaBasic/src/FileDemo/MySQL1.txt";
	/**
	 * 	���ļ��ķ���
	 * @param filepath
	 * @return
	 */
	public static String Scan(String filepath) {
		StringBuffer sb = null;
		Scanner in = null;
		try {
			 in	= new Scanner(new File(filepath));
			 sb = new StringBuffer();
			while(in.hasNext()) {
				sb.append(in.nextLine());
				sb.append(System.getProperty("line.separator"));
			}
			//ȥ�����һ�е�ϵͳ�ָ���
			sb.delete(sb.lastIndexOf(System.getProperty("line.separator")), sb.length());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}finally {
			in.close();
		}
		return sb.toString();
	}
	/**
	 * 	���ļ�������������
	 * @param filepath
	 * @return
	 */
	public static String ScanV1(String filepath) {
		StringBuffer sb = null;
		try(Scanner in	= new Scanner(new File(filepath));) {
			 sb = new StringBuffer();
			while(in.hasNext()) {
				sb.append(in.nextLine());
				sb.append(System.getProperty("line.separator"));//���ϵͳ�ķָ�������ƽ̨��
			}
			//ȥ�����һ�е�ϵͳ�ָ���
			sb.delete(sb.lastIndexOf(System.getProperty("line.separator")), sb.length());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return sb.toString();
	}
	/**
	 * 	д���ļ��ķ���
	 * @param filepath
	 * @param str
	 * @param ISW
	 */
	public static void Print(String filepath , String str) {
		try(PrintWriter pw = new PrintWriter(filepath2);) {
			pw.write(str);
			System.out.println("д��ɹ�!");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 	д�뷽��������
	 * @param filepath
	 * @param str
	 * @param ISW
	 */
	public static void PrintV1(String filepath , String str , boolean ISW) {
		try(PrintWriter pw = new PrintWriter(new FileWriter(filepath2, ISW));) {
			pw.write(str);
			System.out.println("д��ɹ�!");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	public static void main(String[] args) {
		System.out.println(Scan(filepath));
		PrintV1(filepath2, ScanV1(filepath),false);
	}

}
