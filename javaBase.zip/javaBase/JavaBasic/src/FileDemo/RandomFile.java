package FileDemo;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
/**
 * 	������
 * @author 19760
 *
 */
public class RandomFile {
	//	private static final String filepath = "E:\\JavaStudy\\JavaBasic\\src\\FileDemo\\MySQL1.txt";
		private static final String filepath2 = "http://ftp.jaist.ac.jp/pub/eclipse/oomph/epp/photon/R/eclipse-inst-win64.exe";
		private static final int MAX_BUFFER_SIZE = 1024*10240;
		public static void Download() {
			HttpURLConnection connection = null;
			BufferedInputStream bInputStream = null;
			RandomAccessFile rAccessFile = null;
			try {
				URL url = new URL(filepath2);
				connection = (HttpURLConnection) url.openConnection();
				connection.setRequestProperty("Range", "bytes=0-");
				connection.connect();
				if(connection.getResponseCode()/100 != 2) {
					System.out.println("����������ʧ�ܣ�");
					return;
				}
				int download = 0;
				bInputStream = new BufferedInputStream(connection.getInputStream(), MAX_BUFFER_SIZE);
				rAccessFile = new RandomAccessFile(url.getFile().substring(url.getFile().lastIndexOf("/")+1), "rw");
				rAccessFile.seek(0);
				rAccessFile.setLength(0);
				while(download < connection.getContentLength()) {
					byte []b = null;
					if(connection.getContentLength() - download >MAX_BUFFER_SIZE) {
						b = new byte[MAX_BUFFER_SIZE];
					}
					else {b = new byte[connection.getContentLength()-download];}
					int read = bInputStream.read(b);
					if(read == -1) {break;}
					rAccessFile.seek(download);
					rAccessFile.write(b,0,read);
					download += read;
					System.out.printf("��ǰ���ؽ���Ϊ��%.2f%%\n",download*1.0/connection.getContentLength()*100);
					//JOptionPane.showMessageDialog(null,String.format("��ǰ���ؽ���Ϊ��%.2f%%\n",download*1.0/connection.getContentLength()*100));
				}
				
			} catch (MalformedURLException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}finally {	
				try {
					connection.disconnect();
					rAccessFile.close();
					bInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		public static void main(String[] args) {
			Download();
		}
}
