package FileDemo;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;

class ProgressBarDemo implements ActionListener, ChangeListener {
	JFrame frame = null;
	JProgressBar progressbar;
	JLabel label;
	Timer timer;
	JButton b;

	public ProgressBarDemo() {
		frame = new JFrame("�ָ��");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container content = frame.getContentPane();
		label = new JLabel(" ", JLabel.CENTER);
		progressbar = new JProgressBar();// ����һ��������
		progressbar.setOrientation(JProgressBar.HORIZONTAL);
		progressbar.setMinimum(0);
		progressbar.setMaximum(100);
		progressbar.setValue(0);
		progressbar.setStringPainted(true);
		progressbar.addChangeListener(this);
		progressbar.setPreferredSize(new Dimension(300, 20));
		progressbar.setBorderPainted(true);
		progressbar.setBackground(Color.pink);
		JPanel panel = new JPanel();
		b = new JButton("��װ");
		b.setForeground(Color.blue);// �����¼�����
		b.addActionListener(this);
		panel.add(b);
		timer = new Timer(100, this);
		content.add(panel, BorderLayout.NORTH);
		content.add(progressbar, BorderLayout.CENTER);
		content.add(label, BorderLayout.SOUTH);
		frame.pack();
		frame.setVisible(true);
	}

// ʵ���¼������ķ���
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == b)
			timer.start();
		if (e.getSource() == timer) {
			int value = progressbar.getValue();
			if (value < 100) {
				progressbar.setValue(++value);
			} else {
				timer.stop();
				frame.dispose();
			}
		}
	}

	public void stateChanged(ChangeEvent e1) {
		int value = progressbar.getValue();
		if (e1.getSource() == progressbar) {
			label.setText("Ŀǰ����ɽ���:" + Integer.toString(value) + "%");
			label.setForeground(Color.blue);
		}
	}
}

public class Process {
	public static void main(String[] args) {
		new ProgressBarDemo();
	}
}
