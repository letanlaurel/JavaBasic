package Impl;
public class Test implements Eat{

	public int i = 0;
}
