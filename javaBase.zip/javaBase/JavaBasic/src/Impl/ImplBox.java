package Impl;
public class ImplBox implements IlinkBox{

	@Override
	public String Color() {
		return "��ɫ";
	}
}
