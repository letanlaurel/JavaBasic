package Impl;

public interface Eat {
	default void p(){
		System.out.println("�ԳԳԳԳԳ�");
	}
}
