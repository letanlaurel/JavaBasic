package Impl;

public class Implpaper implements Ipaper{

	@Override
	public String size() {
		return "A4";
	}

}
