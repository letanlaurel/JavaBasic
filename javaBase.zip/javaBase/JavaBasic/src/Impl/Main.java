package Impl;

public class Main {
	public static void main(String[] args) {
		Test t = new Test();
		t.p();
	}
}
