package Impl;

public interface IRunning{
   void p();
}
