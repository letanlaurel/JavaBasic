package gui;

public class Classes {
	private String id;//���
	private String tshow;//����
	public Classes() {
		
	}
	public Classes( String tshow) {
		super();
	//	this.id = id;
		this.tshow = tshow;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTshow() {
		return tshow;
	}
	public void setTshow(String tshow) {
		this.tshow = tshow;
	}
	
}
