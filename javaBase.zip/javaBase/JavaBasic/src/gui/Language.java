package gui;

public class Language {
	private int id;//���
	private String name;//����
	private String Lgclass;//��������
	public Language() {}
	public Language( String name, String lgclass) {
		super();
	//	this.id = id;
		this.name = name;
		Lgclass = lgclass;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLgclass() {
		return Lgclass;
	}
	public void setLgclass(String lgclass) {
		Lgclass = lgclass;
	}
	
}
