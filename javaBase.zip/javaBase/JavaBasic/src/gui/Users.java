package gui;
/**
 * users��
 * @author 19760
 *
 */
public class Users {
	private String stuId;//ѧ��
	private String classId;//�༶���
	private String name;//����
	private String gender;//�Ա�
	
	public Users() {
		super();
	}
	
	public Users(String classId, String name, String gender) {
		super();
	//	this.stuId = stuId;
		this.classId = classId;
		this.name = name;
		this.gender = gender;
	}
	public void show() {
		System.out.println(getClassId()+"\t"+getName()+"\t"+getGender());
	}
	
	public String getStuId() {
		return stuId;
	}
	public void setStuId(String stuId) {
		this.stuId = stuId;
	}
	public String getClassId() {
		return classId;
	}
	public void setClassId(String classId) {
		this.classId = classId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	
}
