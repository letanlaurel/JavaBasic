package gui;

public class Examcontestinfo {
	private int id;//���
	private int testid;//������
	private int gameid;//�������α��
	private int testvalue;//�����ֵ
	public Examcontestinfo() {
		
	}
	public Examcontestinfo(int testid, int gameid, int testvalue) {
		super();
		//this.id = id;
		this.testid = testid;
		this.gameid = gameid;
		this.testvalue = testvalue;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTestid() {
		return testid;
	}
	public void setTestid(int testid) {
		this.testid = testid;
	}
	public int getGameid() {
		return gameid;
	}
	public void setGameid(int gameid) {
		this.gameid = gameid;
	}
	public int getTestvalue() {
		return testvalue;
	}
	public void setTestvalue(int testvalue) {
		this.testvalue = testvalue;
	}
	
}
