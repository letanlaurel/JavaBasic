package gui;

public class Examsubmits {
	private int id;//���
	private int teamid;//��Ա���
	private int gametestid;//����������
	private int lgid;//�����������
	private String time;//�ύʱ��
	private String result;//�ύ���
	public Examsubmits() {}
	public Examsubmits(int teamid, int gametestid, int lgid, String time, String result) {
		super();
	//	this.id = id;
		this.teamid = teamid;
		this.gametestid = gametestid;
		this.lgid = lgid;
		this.time = time;
		this.result = result;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTeamid() {
		return teamid;
	}
	public void setTeamid(int teamid) {
		this.teamid = teamid;
	}
	public int getGametestid() {
		return gametestid;
	}
	public void setGametestid(int gametestid) {
		this.gametestid = gametestid;
	}
	public int getLgid() {
		return lgid;
	}
	public void setLgid(int lgid) {
		this.lgid = lgid;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	
}
