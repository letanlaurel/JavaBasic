package gui;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

public class 读文件方式 {

	public static void main(String[] args) throws IOException {
		InputStream stream = ClassLoader.getSystemResourceAsStream("users.txt");
		BufferedInputStream bf = new BufferedInputStream(stream);
		byte a[]  = new byte[10000];
		bf.read(a);
		System.out.println(new String(a));
		
		
	}

}
