package gui;

public class Teamses {
	private int id;//编号
	private int gameid;//比赛编号
	private String stuId;//学号
	public Teamses() {
		
	}
	public Teamses( int gameid, String stuId) {
		super();
		//this.id = id;
		this.gameid = gameid;
		this.stuId = stuId;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getGameid() {
		return gameid;
	}
	public void setGameid(int gameid) {
		this.gameid = gameid;
	}
	public String getStuId() {
		return stuId;
	}
	public void setStuId(String stuId) {
		this.stuId = stuId;
	}
	
}
