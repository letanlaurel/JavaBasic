package gui;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
public class Tlclass {
		/**
		 * ��txt�ĵ���������ݴ���map����ȥ
		 * @return
		 * @throws IOException
		 */ 
		Map<String ,String > mp = new HashMap<String , String>(); 
	    public Map<String , String> itin() throws IOException{
	    	@SuppressWarnings("resource")
			BufferedReader br = new BufferedReader(new FileReader("\\javaAWT\\src\\classes.txt"));
	    	String s = "";
	    	int n = 0;
	    	while((s =br.readLine() )!=null){
	    		if(n<2){
	    			n++;
	    		continue;
	    		}else{
	    			String[]g = s.split("\t");
					mp.put(g[0].trim(), g[1].trim());
	    		}
	    	}
			return mp;   	
	    }
	    public static void main(String[] args) throws IOException {
			Tlclass tl = new Tlclass();
			for(Entry<String, String> i:tl.itin().entrySet()){
				System.out.print(i.getKey()+":\t");
				System.out.println(i.getValue());
			}
		}

}
