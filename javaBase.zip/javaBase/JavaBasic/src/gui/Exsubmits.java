package gui;

public class Exsubmits {
	private int id;//��� 
	private int lgid;//���Ա�� 
	private int testid;//��Ŀ���
	private String stuid;//ѧ��
	private String time;//�ύʱ��
	private String result;//�ж����
	
	public Exsubmits () {}

	public Exsubmits( int lgid, int testid, String stuid, String time, String result) {
		super();
		this.lgid = lgid;
		this.testid = testid;
		this.stuid = stuid;
		this.time = time;
		this.result = result;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getLgid() {
		return lgid;
	}

	public void setLgid(int lgid) {
		this.lgid = lgid;
	}

	public int getTestid() {
		return testid;
	}

	public void setTestid(int testid) {
		this.testid = testid;
	}

	public String getStuid() {
		return stuid;
	}

	public void setStuid(String stuid) {
		this.stuid = stuid;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}
	
}
