package gui;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
/**
 *
 * @author 19760
 *
 */
public class MapTree { 
	static Map<Object , Object> m = null;
	public MapTree() {
		
	}
	public static void main(String[] args) {
		UseR();
	}
	/**
	 * UseR方法
	 * Users 
	 */
	public static void UseR() {
			m = new TreeMap<>();
		final String filepath = "src/users.txt";
		Map<String, Users> usmap = Readfile(filepath);
		for (String key : usmap.keySet()) {
//			for (Object key1 : map.keySet()) {
//				if(key.equals(map.get(key1).getStuId())) {
//					m.put(key, usmap.get(key)+"\t"+map.get(key1).getId()+"\t"+map.get(key1).getGameid());
////					System.out.println(key+"\t"+usmap.get(key).getClassId()+"\t"+usmap.get(key).getName()+"\t"+usmap.get(key).getGender()+
////							"\t"+map.get(key1).getId()+"\t"+map.get(key1).getGameid());
//				}
//			}	
			System.out.println(key +"\t"+ usmap.get(key).getClassId()+"\t"+usmap.get(key).getName()+"\t"+usmap.get(key).getGender());
		}
//		for (Object key  : m.keySet()) {
//			System.out.println(key +"\t"+m.get(key));}
	}
	/**
	 * Users
	 * @param filepath
	 * @return
	 */
	public static Map<String , Users> Readfile(String filepath){
		Map<String , Users> usmp = new LinkedHashMap<>();
		try(
				FileReader freader = new FileReader(filepath);
				BufferedReader reader = new BufferedReader(freader);
			){
				String line = null;
				int i = 1;
				while((line = reader.readLine()) != null){
					if(i++ ==1)
					{	continue;}//第一行不读
					if(line.length() == 0)
					{	continue;}//读掉空串
					String a[] = line.trim().split("\t");//将字符串分割
					if(i == 3)
					{a1(a[0],a[1],a[2],a[3]);//第一行标题
					continue;}
					usmp.put(a[0].trim(), new Users(a[1].trim(),a[2].trim(),a[3].trim()));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return usmp;
	}
	//Users标题
	public static void a1(String ...a) {
		System.out.println(a[0]+"\t\t"+a[1]+"\t"+a[2]+"\t"+a[3]);
	}
	
	
	
	
	/**
	 * Teamses
	 */
	public static void Tea() {
	final String filepath = "E:/JavaStudy/JavaGUI/src/teamses.txt";
	Map<Integer, Teamses> usmap = Readfile1(filepath);
	for (Integer key : usmap.keySet()) {
		System.out.println(key +"\t"+ usmap.get(key).getGameid()+"\t"+usmap.get(key).getStuId());
	}
}
	/**
	 * Teamses
	 * @param filepath1
	 * @return
	 */
	public static Map<Integer , Teamses> Readfile1(String filepath){
	Map<Integer , Teamses> usmp = new LinkedHashMap<>();
	try(
			FileReader freader = new FileReader(filepath);
			BufferedReader reader = new BufferedReader(freader);
		){
			String line = null;
			int i = 1;
			while((line = reader.readLine()) != null){
				if(i++ ==1)
				{	continue;}//第一行不读
				if(line.length() == 0)
				{	continue;}//读掉空串
				String a[] = line.trim().split("\t");
				if(i == 3)
				{a1(a[0],a[1],a[2]);
				continue;}
				usmp.put(Integer.parseInt(a[0].trim()), new Teamses(Integer.parseInt(a[1].trim()),a[2].trim()));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	return usmp;
}
	//Teamses
	public static void a2(String ...a) {
		System.out.println(a[0]+"\t"+a[1]+"\t"+a[2]);
	}
	
	
	
	
	/**
	 * Questiontype
	 */
	public static void Questiontypet() {
		final String filepath = "E:/JavaStudy/JavaGUI/src/questiontype.txt";
		Map<Integer, Questiontype> usmap = Readfile2(filepath);
		for (Integer key : usmap.keySet()) {
			System.out.println(key +"\t"+ usmap.get(key).getQuestion());
		}
	}
		/**
		 * Questiontype
		 * @param filepath2
		 * @return
		 */
	public static Map<Integer , Questiontype> Readfile2(String filepath){
		Map<Integer , Questiontype> usmp = new LinkedHashMap<>();
		try(
				FileReader freader = new FileReader(filepath);
				BufferedReader reader = new BufferedReader(freader);
			){
				String line = null;
				int i = 1;
				while((line = reader.readLine()) != null){
					if(i++ ==1)
					{	continue;}
					if(line.length() == 0)
					{	continue;}
					String a[] = line.trim().split("\t");
					if(i == 3 )
					{a3(a[0],a[1]);
					continue;}
					usmp.put(Integer.parseInt(a[0].trim()), new Questiontype(a[1].trim()));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return usmp;
	}
		//Questiontype
	public static void a3(String ...a) {
			System.out.println(a[0]+"\t"+a[1]);
		}
		
		
		
		/**
		 * Questions
		 */
	public static void Questionst() {
			final String filepath = "E:/JavaStudy/JavaGUI/src/questions.txt";
			Map<Integer, Questions> usmap = Readfile3(filepath);
			for (Integer key : usmap.keySet()) {
				System.out.println(key +"\t"+ usmap.get(key).getTestclass()+"\t"+usmap.get(key).getTestshow());
			}
		}
		/**
		 * Questions
		 * @param filepath3
		 * @return
		 */
	public static Map<Integer , Questions> Readfile3(String filepath){
			Map<Integer , Questions> usmp = new LinkedHashMap<>();
			try(
					FileReader freader = new FileReader(filepath);
					BufferedReader reader = new BufferedReader(freader);
				){
					String line = null;
					int i = 1;
					while((line = reader.readLine()) != null){
						if(i++ ==1)
						{	continue;}
						if(line.length() == 0)
						{	continue;}
						String a[] = line.trim().split("\t");
					//	System.out.println(line);
						if(i == 3)
						{a4(a[0],a[1],a[2]);
						continue;}
						usmp.put(Integer.parseInt(a[0].trim()), new Questions(Integer.parseInt(a[1].trim()),a[2].trim()));
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			return usmp;
		}
		 //Questiontype
	public static void a4(String ...a) {
				System.out.println(a[0]+"\t"+a[1]+"\t"+a[2]);
			}
		
		
		
		/**
		 * Language
		 */
	public static void Languaget() {
		final String filepath = "E:/JavaStudy/JavaGUI/src/language.txt";
		Map<Integer, Language> usmap = Readfile4(filepath);
		for (Integer key : usmap.keySet()) {
			System.out.println(key +"\t"+ usmap.get(key).getName()+"\t"+usmap.get(key).getLgclass());
		}
	}
		/**
		 * Language
		 * @param filepath4
		 * @return
		 */
	public static Map<Integer , Language> Readfile4(String filepath){
		Map<Integer , Language> usmp = new LinkedHashMap<>();
		try(
				FileReader freader = new FileReader(filepath);
				BufferedReader reader = new BufferedReader(freader);
			){
				String line = null;
				int i = 1;
				while((line = reader.readLine()) != null){
					if(i++ ==1)
					{	continue;}//
					if(line.length() == 0)
					{	continue;}//
					String a[] = line.trim().split("\t");
				//	System.out.println(line);
					if(i == 3)
					{a5(a[0],a[1],a[2]);
					continue;}
					usmp.put(Integer.parseInt(a[0].trim()), new Language(a[1].trim(),a[2].trim()));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return usmp;
	}
		 //Language
	public static void a5(String ...a) {	
	System.out.println(a[0]+"\t"+a[1]+"\t"+a[2]);
}
		
		
		
		/**
		 * Exsubmits
		 */
	public static void Exsubmitst() {
		final String filepath = "E:/JavaStudy/JavaGUI/src/exsubmits.txt";
		Map<Integer, Exsubmits> usmap = Readfile5(filepath);
		//int i = 1;
		for (Integer key : usmap.keySet()) {
			//++i;
			System.out.println(key +"\t"+ usmap.get(key).getLgid()+"\t"+
					usmap.get(key).getTestid()+"\t"+usmap.get(key).getStuid()+"\t"+
					usmap.get(key).getTime()+"\t"+usmap.get(key).getResult());
		}
	}
		/**
		 * Exsubmits
		 * @param filepath5
		 * @return
		 */
	public static Map<Integer , Exsubmits> Readfile5(String filepath){
		Map<Integer , Exsubmits> usmp = new LinkedHashMap<>();
		try(
				FileReader freader = new FileReader(filepath);
				BufferedReader reader = new BufferedReader(freader);
			){
				String line = null;
				int i = 1;
				while((line = reader.readLine()) != null){
					if(i++ ==1)
					{	continue;}
					if(line.length() == 0)
					{	continue;}
					String a[] = line.trim().split("\t");
				//	System.out.println(line);
					if(i == 3)
					{a6(a[0],a[1],a[2],a[3],a[4],a[5]);
					continue;}
					usmp.put(Integer.parseInt(a[0].trim()), new Exsubmits(Integer.parseInt(a[1].trim()),Integer.parseInt(a[2].trim()),a[3].trim(),a[4].trim(),a[5].trim()));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return usmp;
	}
		 //Exsubmits
	public static void a6(String ...a) {	
	System.out.println(a[0]+"\t"+a[1]+"\t"+a[2]+"\t"+a[3]+"\t"+a[4]+"\t"+a[5]);
}
		
		
		
		
		
	/**
	 * Examsubmits
	 */
	public static void Examsubmits() {
	final String filepath = "E:/JavaStudy/JavaGUI/src/examsubmits.txt";
	Map<Integer, Examsubmits> usmap = Readfile6(filepath);
	//int i = 1;
	for (Integer key : usmap.keySet()) {
		//++i;
		System.out.println(key +"\t"+ usmap.get(key).getTeamid()+"\t"+
				usmap.get(key).getGametestid()+"\t"+usmap.get(key).getLgid()+"\t"+
				usmap.get(key).getTime()+"\t"+usmap.get(key).getResult());
	}
}
	/**
	 * Examsubmits
	 * @param filepath5
	 * @return
	 */
	public static Map<Integer , Examsubmits> Readfile6(String filepath){
	Map<Integer , Examsubmits> usmp = new LinkedHashMap<>();
	try(
			FileReader freader = new FileReader(filepath);
			BufferedReader reader = new BufferedReader(freader);
		){
			String line = null;
			int i = 1;
			while((line = reader.readLine()) != null){
				if(i++ ==1)
				{	continue;}
				if(line.length() == 0)
				{	continue;}
				String a[] = line.trim().split("\t");
			//	System.out.println(line);
				if(i == 3)
				{a7(a[0],a[1],a[2],a[3],a[4],a[5]);
				continue;}
				usmp.put(Integer.parseInt(a[0].trim()), new Examsubmits(Integer.parseInt(a[1].trim()),Integer.parseInt(a[2].trim()),Integer.parseInt(a[3].trim()),a[4].trim(),a[5].trim()));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	return usmp;
}
	 //Examsubmits
	public static void a7(String ...a) {	
		System.out.println(a[0]+"\t"+a[1]+"\t"+a[2]+"\t"+a[3]+"\t"+a[4]+"\t"+a[5]);
	}
			
		
		
		
		
		
	/**
	 * Examinfoͳ
	 */
	public static void Examinfoͳt() {
		final String filepath = "E:/JavaStudy/JavaGUI/src/examinfo.txt";
		Map<Integer, Examinfo> usmap = Readfile7(filepath);
		for (Integer key : usmap.keySet()) {
			System.out.println(key +"\t"+ usmap.get(key).getGamequestion()+"\t"+usmap.get(key).getStime()+"\t"+usmap.get(key).getEtime());
		}
	}
	/**
	 * Examinfo
	 * @param filepath7
	 * @return
	 */
	public static Map<Integer , Examinfo> Readfile7(String filepath){
		Map<Integer , Examinfo> usmp = new LinkedHashMap<>();
		try(
				FileReader freader = new FileReader(filepath);
				BufferedReader reader = new BufferedReader(freader);
			){
				String line = null;
				int i = 1;
				while((line = reader.readLine()) != null){
					if(i++ ==1)
					{	continue;}
					if(line.length() == 0)
					{	continue;}
					String a[] = line.trim().split("\t");
					if(i == 3)
					{a8(a[0],a[1],a[2],a[3]);
					continue;}
					usmp.put(Integer.parseInt(a[0].trim()), new Examinfo(a[1].trim(),a[2].trim(),a[3].trim()));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return usmp;
	}
		//Examinfo
	public static void a8(String ...a) {
		System.out.println(a[0]+"\t\t"+a[1]+"\t"+a[2]+"\t"+a[3]);
	}
		
		
	
	
	
	/**
	 * Examcontestinfo
	 */
	public static void Examcontestinfot() {
		final String filepath = "E:/JavaStudy/JavaGUI/src/examcontestinfo.txt";
		Map<Integer, Examcontestinfo> usmap = Readfile8(filepath);
		for (Integer key : usmap.keySet()) {
			System.out.println(key +"\t"+ usmap.get(key).getTestid()+"\t"+usmap.get(key).getGameid()+"\t"+usmap.get(key).getTestvalue());
		}
	}
	/**
	 * Examcontestinfo
	 * @param filepath7
	 * @return
	 */
	public static Map<Integer , Examcontestinfo> Readfile8(String filepath){
		Map<Integer , Examcontestinfo> usmp = new LinkedHashMap<>();
		try(
				FileReader freader = new FileReader(filepath);
				BufferedReader reader = new BufferedReader(freader);
			){
				String line = null;
				int i = 1;
				while((line = reader.readLine()) != null){
					if(i++ ==1)
					{	continue;}
					if(line.length() == 0)
					{	continue;}
					String a[] = line.trim().split("\t");
					if(i == 3)
					{a9(a[0],a[1],a[2],a[3]);
					continue;}
					usmp.put(Integer.parseInt(a[0].trim()), new Examcontestinfo(Integer.parseInt(a[1].trim()),Integer.parseInt(a[2].trim()),Integer.parseInt(a[3].trim())));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return usmp;
	}
		//Examcontestinfo
	public static void a9(String ...a) {
		System.out.println(a[0]+"\t"+a[1]+"\t"+a[2]+"\t"+a[3]);
		}
		
	
	
	
		/**
		 * Classes
		 */
	public static void Classest() {
		final String filepath = "E:/JavaStudy/JavaGUI/src/classes.txt";
		Map<String, Classes> usmap = Readfile9(filepath);
		for (String key : usmap.keySet()) {
			System.out.println(key +"\t"+ usmap.get(key).getTshow());
		}
	}
		/**
		 * Classes
		 * @param filepath2
		 * @return
		 */
	public static Map<String , Classes> Readfile9(String filepath){
		Map<String , Classes> usmp = new LinkedHashMap<>();
		try(
				FileReader freader = new FileReader(filepath);
				BufferedReader reader = new BufferedReader(freader);
			){
				String line = null;
				int i = 1;
				while((line = reader.readLine()) != null){
					if(i++ ==1)
					{	continue;}
					if(line.length() == 0)
					{	continue;}
					String a[] = line.trim().split("\t");
					if(i == 3 )
					{a10(a[0],a[1]);
					continue;}
					usmp.put(a[0].trim(), new Classes(a[1].trim()));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		return usmp;
	}
		//Questiontype
	public static void a10(String ...a) {
			System.out.println(a[0]+"\t"+a[1]);
		}
		
	
	
	
	
		
		
}




