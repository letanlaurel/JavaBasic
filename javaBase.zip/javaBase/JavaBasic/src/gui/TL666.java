package gui;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.table.JTableHeader;

@SuppressWarnings("serial")
public class TL666 extends JFrame {
	JTable jt;
	JPanel jp;
	@SuppressWarnings("rawtypes")
	JComboBox tl;

	public static void main(String[] args) {
		TL666 tl = new TL666();
		tl.LGG();
	}

	public void LG() {
		final Object[] a = { "name", "gender", "place", "stuId" };
		Object[][] b = { { "����", "��", "����", "1700130101" }, { "�����", "Ů", "ɽ��", "1700130102" },
				{ "����", "Ů", "����", "1700130103" }, { "����", "��", "�㶫", "1700130104" } };
		jt = new JTable(b, a);
		jt.setPreferredSize(new Dimension(350, 450));
		jt.setBackground(Color.gray);
		// add(new JScrollPane(jt));//把表格加到窗口上去
		this.add(jt, BorderLayout.SOUTH);
		JTableHeader jh = jt.getTableHeader();
		jh.setEnabled(false);// 设置列表线不可拉伸 
		// this.setVisible(true);//窗口可见
		// this.setDefaultCloseOperation(EXIT_ON_CLOSE);//设置窗口关闭
	}

	public void LGG() {
		jp = new JPanel(new BorderLayout());
		JPanel jpa = new JPanel(new GridLayout(1, 3));
		this.setSize(400, 500);
		// jp.setPreferredSize(new Dimension(280, 80));
		final JRadioButton jb = new JRadioButton("按钮1");// 定义一个按钮
		final JRadioButton jb1 = new JRadioButton("按钮2");
		final JRadioButton jb2 = new JRadioButton("按钮3");
		ButtonGroup bg = new ButtonGroup();
		/**
		 * 添加监听器 
		 */
		jb1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				jt.setVisible(false);
				tl.setVisible(true);
			}
		});
		jb2.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				jt.setVisible(false);
				tl.setVisible(false);

			}
		});
		jb.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				jt.setVisible(true);
				tl.setVisible(true);
			}
		});
		bg.add(jb);
		bg.add(jb1);
		bg.add(jb2);
		jpa.add(jb);
		jpa.add(jb1);
		jpa.add(jb2);

		JPanel pan = new JPanel(new BorderLayout());
		JLabel label = new JLabel("aaaaaaaaaa");
		JSeparator jSeparator = new JSeparator();
		pan.add(jSeparator, BorderLayout.SOUTH);
		pan.add(label, BorderLayout.NORTH);
		jp.add(pan, BorderLayout.CENTER);
		jp.add(jpa, BorderLayout.NORTH);
//		this.add(jSeparator,BorderLayout.CENTER);
//		this.add(label,BorderLayout.CENTER);
		// this.pack();
		// jp.setBackground(Color.blue);//背景颜色
		this.add(jp);// 最上边
		// this.setContentPane(jp);
		TLGG();
		LG();
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setLayout(new FlowLayout());
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void TLGG() {
		// jp1.setPreferredSize(new Dimension(50,50));//设置按钮大小 
		Integer[] a = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26,
				27, 28, 29, 30 };
		tl = new JComboBox(a);// 把数字放到选择按钮中
		// tl.setBounds(10,20,40,40);//设置按钮在窗口的位置
		tl.setSize(20, 20);// 设置按钮的大小
		jp.add(tl);// 往界面添加按钮
		// jp1.setBackground(Color.green);
		this.add(jp);// 中间
		this.setVisible(true);// 窗口可见
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// 窗口关闭
		this.setLayout(new FlowLayout());// 按钮布局
	}

}
