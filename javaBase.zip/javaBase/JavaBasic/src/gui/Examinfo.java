package gui;

public class Examinfo {
	private int id;//���
	private String gamequestion;//��������
	private String stime;//��ʼʱ��
	private String etime;//����ʱ��
	public Examinfo() {

	}
	public Examinfo( String gamequestion, String stime, String etime) {
		super();
		//this.id = id;
		this.gamequestion = gamequestion;
		this.stime = stime;
		this.etime = etime;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getGamequestion() {
		return gamequestion;
	}
	public void setGamequestion(String gamequestion) {
		this.gamequestion = gamequestion;
	}
	public String getStime() {
		return stime;
	}
	public void setStime(String stime) {
		this.stime = stime;
	}
	public String getEtime() {
		return etime;
	}
	public void setEtime(String etime) {
		this.etime = etime;
	}
	
}
