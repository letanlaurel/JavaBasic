package gui;

public class Questions {
	private int testid;//��Ŀ���
	private int testclass;//��Ŀ����
	private String testshow;//��Ŀ����
	public Questions() {}
	
	public Questions(int testclass, String testshow) {
		super();
	//	this.testid = testid;
		this.testclass = testclass;
		this.testshow = testshow;
	}

	public int getTestid() {
		return testid;
	}
	public void setTestid(int testid) {
		this.testid = testid;
	}
	public int getTestclass() {
		return testclass;
	}
	public void setTestclass(int testclass) {
		this.testclass = testclass;
	}
	public String getTestshow() {
		return testshow;
	}
	public void setTestshow(String testshow) {
		this.testshow = testshow;
	}
	
}
