import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class fafwa {
	public static void main(String[] args) throws Exception {
		Calendar cd = Calendar.getInstance();
		SimpleDateFormat sm = new SimpleDateFormat("yyyy-MM-dd");
		Date date = sm.parse("2015-10-01");
		cd.setTime(date);
		cd.add(Calendar.DAY_OF_YEAR, 10000);
		String string = sm.format(cd.getTime());
		System.out.println(string);
		System.out.println(getDate("2015-10-01", 13));

	}

	public static String getDate(String releaseDate, int day) {
		/********* Begin *********/
		Calendar cd = Calendar.getInstance();
		SimpleDateFormat sm = new SimpleDateFormat("yyyy-MM-dd");
		try {
			cd.setTime(sm.parse(releaseDate));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		cd.add(Calendar.DAY_OF_YEAR, day);
		return sm.format(cd.getTime());
		/********* End *********/
	}
}
