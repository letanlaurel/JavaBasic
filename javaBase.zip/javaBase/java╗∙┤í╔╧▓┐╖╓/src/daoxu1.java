import java.util.Scanner;


public class daoxu1 {

	/**��������
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		input.close();
		for (int i = 0; i < n; i++) {
			int count = input.nextInt();
			while (count!=0){
				int a= -1;
				a=count%10;
				count/=10;
				System.out.print(a);
			}
			System.out.println();
		}
	}

}
