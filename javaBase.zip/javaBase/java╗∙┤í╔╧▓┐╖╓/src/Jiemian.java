import java.awt.Button;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class Jiemian {

	/**��һ������
	 * @param args
	 */
	public static void main(String[] args) {
		Frame F = new Frame("�ָ�Ĵ���");
		F.setLayout(new FlowLayout(4,10,100));
		F.setSize(400, 200);
		F.setLocation(500, 600);
		F.setVisible(true);
		F.setBackground(Color.yellow);
		Button btn = new Button("�˳�");
		F.add(btn);
		btn.addMouseListener(new MouseListener() {
			
			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void mouseClicked(MouseEvent e) {
				System.exit(0);
				
			}
		});
	}

	@SuppressWarnings("unused")
	private static void setBackground(Color blue) {
		// TODO Auto-generated method stub
		
	}
	

}
