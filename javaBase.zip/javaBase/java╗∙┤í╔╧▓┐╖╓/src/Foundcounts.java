import java.util.Scanner;

public class Foundcounts {

	/**��ȡ�ַ����е�����
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String str =input.nextLine();
	    String str2 = "";
	    input.close();
		if (str != null && "".equals(str)) {
			for (int i = 0; i < str.length(); i++){
				if (str.charAt(i) >=48 && str.charAt(i) <= 57) {
					str2 += str.charAt(i);
				}
			}
			System.out.println(str2);
		}
	}

}

	
