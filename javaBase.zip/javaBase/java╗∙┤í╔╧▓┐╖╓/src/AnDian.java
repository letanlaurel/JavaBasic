import java.util.Scanner;

public class AnDian {
	/**
	 * ��������
	 * 
	 * �����������룺
		2
		2
		1 3
		3 4
		3
		1 2 3
		4 4 4
		2 2 3
		�����������
		1,2;
		1,3;3,3;
	 * @param args
	 */
	public static void main(String[] args) {
		Input();
	}
	public static void Input(){
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		for (int k = 0; k < n; k++) {
			int N = input.nextInt();
			if(N<=30&&N>0){
			int[][] a = new int[N][N];
			for (int i = 0; i < a.length; i++) {
				for (int j = 0; j < a.length; j++) {
					a[i][j] = input.nextInt();
				}
			}
			TLfound(a);
		}
		}
		input.close();
	}
	public static void TLfound(int a[][]) {
		@SuppressWarnings("unused")
		int k = 0, t = 0 , s = 0 , max = 0, min = 0;
		boolean l = false;
		for (int i = 0; i < a.length; i++) {
			max = a[i][0];
			k = i; t = 0;
			for (int j = 1; j < a.length; j++) {
				if (max < a[i][j]) {
					max = a[i][j];
					k = i;
					t = j;
				}
			}s = k ;
			min = a[k][t];
			for (int j = 0; j < a.length; j++) {
				if (min > a[j][t]) {
					min = a[j][t];
					s = j;
				}
			}
			if (min == max) {
				System.out.printf("%d,%d;", k + 1, t + 1);
				l = true;
			}	
		}
		if(!l){
			System.out.println("NO;");
		}
		else{
			System.out.println();
		}
	}
}
