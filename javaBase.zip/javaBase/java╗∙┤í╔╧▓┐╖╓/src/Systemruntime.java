

public class Systemruntime {

	/**����ϵͳ����ʱ��
	 * @param args
	 */
	public static void main(String[] args) {
		int i = 0;//����
		long starttime = System.currentTimeMillis();
		while (true) {
			if(i++==Integer.MAX_VALUE)
				break;
		}
		long endtime = System.currentTimeMillis();
		System.out.println(endtime-starttime);
	}

}