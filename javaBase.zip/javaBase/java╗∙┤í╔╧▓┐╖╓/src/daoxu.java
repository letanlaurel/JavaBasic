import java.util.Scanner;


public class daoxu {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		input.close();
		for (int i = 0; i < n; i++) {
			String str = input.next();
			for (int j = str.length()-1; j >= 0; j--) {
				System.out.print(str.charAt(j));
			}
			System.out.println();
		}

	}

}
