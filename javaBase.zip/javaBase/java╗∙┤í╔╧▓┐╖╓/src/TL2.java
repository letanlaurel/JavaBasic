import java.util.Scanner;


public class TL2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		String str=new Scanner(System.in).nextLine(); 
		getfound(str);
	}
	public static void getfound(String str){
		String [] str2 = str.split(" ");
		for (int i = 0; i < str2.length; i++) {
			if("students".equalsIgnoreCase(str2[i])){
				System.out.println(str2[i]);
				break;
			}
		}
	}

}
