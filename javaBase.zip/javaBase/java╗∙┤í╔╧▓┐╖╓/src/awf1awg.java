import java.util.Scanner;


public class awf1awg {
	public static final double PI = 3.14;
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		double R = input.nextDouble();
		input.close();
		if(R>0){
			double S = 4*PI*R*R;
			double V = 4/3.0*PI*R*R*R;
			double s = PI*R*R;
			System.out.printf("%.2f %.2f %.2f\n", S,V,s);
		}
	}
}
