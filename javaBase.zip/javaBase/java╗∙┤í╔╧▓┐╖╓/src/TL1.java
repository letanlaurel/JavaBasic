import java.util.Scanner;


public class TL1 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String str = input.nextLine();
		System.out.println(getplace(str));
		input.close();
	}
public static String getplace(String str){
	String str2 = "";
	str2 = str.replaceAll("ѧԺ", "school");
	return str2;
}
}
