import java.util.Scanner;  
  
public class awgawg{  
    public static void main(String args[]){  
        Scanner input = new Scanner(System.in);  
        while(input.hasNext()){  
            String s = input.nextLine();  
            String s1 = "";//�ַ�����ʼ��  
            if(s != null && !"".equals(s))//ȷ���ַ������ǿ��ַ���  
            {  
                for(int i = 0;i < s.length();i ++){  
                    if(s.charAt(i)>=48 && s.charAt(i)<=57){  
                    s1 = s1 + s.charAt(i);  
                }  
                }  
                System.out.println(s1);  
            }  
        }
        input.close();
    }  
}  