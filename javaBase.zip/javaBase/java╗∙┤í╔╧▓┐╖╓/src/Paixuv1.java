
public class Paixuv1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int []a = {1,3,6,2,5,4,9,7,6,4,45,6,31,15,63,46,4,31,616,6,5,64,64,82,8,346,8,34,83,48,46,8,4,3486,464,};
		for (int i = 0; i < a.length; i++){
			for (int j = 1; j < a.length-1; j++) {
				if(a[j]>a[j+1]){
					int temp = a[j];
					a[j] = a[j+1];
					a[j+1] = temp;
			}
			}
	}
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i]+" ");
		}
	}
}