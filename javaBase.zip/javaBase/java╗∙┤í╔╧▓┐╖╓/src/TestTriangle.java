import java.util.Arrays;
import java.util.Scanner;
public class TestTriangle {  
  
    public static void main(String[] args) {  
        // TODO Auto-generated method stub  
        int []array=new int[3];  
        System.out.println("�����������ε�������");  
        Scanner in=new Scanner(System.in);  
        try{  
            for(int i=0;i<3;i++) {  
                if(in.hasNextInt())   
                    array[i]=in.nextInt();    
            }  
            Arrays.sort(array);  
            Triangle1 triangle=new Triangle1();  
            triangle.triangle(array[0],array[1],array[2]);  
        }  
        catch(IllegalArgumentException e){  
            System.out.println("�쳣��Ϣ:"+e.getMessage());  
        }  
        in.close();
    }  
  
}  