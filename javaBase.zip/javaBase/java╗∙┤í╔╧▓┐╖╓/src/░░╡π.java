public class 鞍点 {  
  
    public static void main(String[] args) {  
        int [][]num=new int[][]{{1,1,1,1},{1,1,1,1},{1,1,1,1}};  
        int re=findIt(num);  
        if(re>0){  
            System.out.println(re);  
        }  
          
  
    }  
      
    public static int findIt(int [][] num){  
        int result=0;  
        boolean flage=false;  
        for(int i=0;i<3;i++){  
            for(int j=0;j<4;j++){  
                if(IsMax(num,j,num[i][j])&&IsMin(num,i,num[i][j])){  
                    result=num[i][j];  
                    //System.out.println(i+"  "+j);  
                    flage=true;  
                }  
            }  
        }  
          
        if(flage){  
        return result;}  
        return -1;  
          
    }  
      
    public static boolean IsMax(int [][] num,int column,int point){  
        int re=point;  
        for(int i=0;i<3;i++){  
            if(re>=num[i][column]){  
                re=num[i][column];}  
        }  
        if(re!=point){  
            return false;  
        }  
        return true;  
    }  
          
          
      
      
      
    public static boolean IsMin(int [][] num,int row,int point){  
        int re=point;  
        for(int i=0;i<4;i++){  
            if(re<=num[row][i])  
                re=num[row][i];  
        }  
        if(re!=point){  
            return false;  
        }  
        return true;  
  
}  
}  