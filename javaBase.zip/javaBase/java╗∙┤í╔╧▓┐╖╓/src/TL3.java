import java.util.Scanner;


public class TL3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner input =new Scanner(System.in);
		int a = input.nextInt();
		int b = input.nextInt();
		int c = input.nextInt();
		System.out.println(getMax(a,b,c));
		input.close();
	}
	public static int getMax(int ...a){
		//a>b?(a>c?a:c):(b>c?b:c)
		return ((a[0]>a[1])?(a[0]>a[2]?a[0]:a[2]):(a[1]>a[2]?a[1]:a[2]));
	}

}
