package tl6;

public class 选择排序 {

	public static void main(String[] args) {
		px(new int[] { 2, 9, 3, 6, 4, 8, 1, 7, 13, 11, 10 });
	}

	public static void px(int... a) {
		for (int i = 0; i < a.length; i++) {
			int min = a[i];// 每次把最左边当作最小值的
			int index = i;// 记录最小值的下标
			for (int j = i + 1; j < a.length; j++) {
				if (a[j] < min) {// 找到整列数组的最小值
					min = a[j];
					index = j;
				}
			}
			// 进行交换
			int temp = a[i];
			a[i] = a[index];
			a[index] = temp;
		}
		// 交换完成后遍历数组
		for (int i : a) {
			System.out.print(i + " ");
		}
	}

}
