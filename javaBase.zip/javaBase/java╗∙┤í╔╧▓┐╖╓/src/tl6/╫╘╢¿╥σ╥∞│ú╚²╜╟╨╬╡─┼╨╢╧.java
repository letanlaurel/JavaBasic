package tl6;

import java.util.InputMismatchException;
import java.util.Scanner;

public class 自定义异常三角形的判断 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		for (int i = 1; i <= N; i++) {
			
			try {
				double a = input.nextDouble();
				double b = input.nextDouble();
				double c = input.nextDouble();
				new Triangle(a,b,c).trianglearea();
			}catch (InputMismatchException e) {
				System.exit(0);
			}catch (Exception e) {
				//System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
		input.close();
	}
}
@SuppressWarnings("serial")
class TriangleExceptiontozero extends Exception {
	public TriangleExceptiontozero() {
		super("Negative Argements");
	}
}

@SuppressWarnings("serial")
class TriangleException extends Exception {
	public TriangleException() {
		super("Not TriAngle");
	}
}
class Triangle {
	private double a;
	private double b;
	private double c;

	public Triangle() {
		// Ĭ�Ϲ���
	}

	public Triangle(double a, double b, double c) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
	}

	public void trianglearea() throws Exception {
		if (a * b * c < 0) {
			throw new TriangleExceptiontozero();
		} else if (a + b > c && a + c > b && b + c > a) {
			double p = (a + b + c) / 2.0;
			double s = Math.sqrt(p * (p - a) * (p - b) * (p - c));
			System.out.printf("%.2f", s);
		} else
			throw new TriangleException();
	}

	public double getA() {
		return a;
	}

	public void setA(double a) {
		this.a = a;
	}

	public double getB() {
		return b;
	}

	public void setB(double b) {
		this.b = b;
	}

	public double getC() {
		return c;
	}

	public void setC(double c) {
		this.c = c;
	}

}