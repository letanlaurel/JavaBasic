package tl6;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class 日期转换为毫秒 {

	public static void main(String[] args) throws ParseException {
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		System.out.println(sf.parse("2013-10-12 12:12:12").getTime());
//		1389339888
	}

}
