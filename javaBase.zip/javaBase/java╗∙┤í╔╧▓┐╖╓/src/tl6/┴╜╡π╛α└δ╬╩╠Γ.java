package tl6;

import java.util.Scanner;

public class 两点距离问题 {

	/**��������
		0 0 4 3
		1.1 -2.3 0 1
		0 0 0 0
		�������
		5.00
		3.48
	 * @param args
	 */
	public static void main(String[] args) {
		Input();
	}
	public static void Input(){
		Scanner input = new Scanner(System.in);
		while(true){
			double a = input.nextDouble();
			double b = input.nextDouble();
			double c = input.nextDouble();
			double d = input.nextDouble();
			if(a == 0 && b == 0 && c == 0 && d == 0){
				System.exit(0);
			}
			TL(a,b,c,d);
			input.close();
		}
		
	}
	public static void TL(double ...a){
		double t = 0;
		t = Math.sqrt(Math.pow(a[0]-a[2],2)+Math.pow(a[1] - a[3],2));
		System.out.printf("%.2f\n",t);
	}

}
