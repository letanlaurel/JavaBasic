package tl6;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class TL66 {
	public static void main(String[] args) {
		JFrame jf = new JFrame("����");
		jf.setSize(500,400);
		JPanel jp = new JPanel();
		jp.setPreferredSize(new Dimension(240,80));
		Integer [] a = {1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30};
		@SuppressWarnings({ "rawtypes", "unchecked" })
		JComboBox tl = new JComboBox(a);
		tl.setBounds(10,20,40,40);
		tl.setSize(30,30);
		jp.add(tl);
		jf.add(jp);
		jf.setVisible(true);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jf.setLayout(new FlowLayout());
	}
}
