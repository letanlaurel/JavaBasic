package tl6;

import java.util.Scanner;

public class 各个位数字之和排序 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Input();
	}
	public static void Input() {
		Scanner input = new Scanner(System.in);
		while (input.hasNext()) {
			int N = input.nextInt();
			if(N == 0){
				System.exit(0);
			}
			int [] a = new int[N];
			for (int i = 0; i < N; i++) {
				a[i] = input.nextInt();
			}
			Tl(a);
		}
		input.close();
	}
	public static int TL(int a){
			int s = 0;
			while(a != 0){
				s += a%10;
				a /=10;
			}
			return s;
		}
	public static void Tl(int []a){
		for (int i = 0; i < a.length; i++) {
			int min = a[i];
			int k = i;
			for (int j = i+1; j < a.length; j++) {
				if(TL(min)>TL(a[j])){
					min = a[j];
					k = j;
				}
			}
			int temp = a[i];
			a[i] = a[k];
			a[k] = temp;		
		}
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i]+" ");
		}System.out.println();
	}
}
