package tl6;

import java.util.Scanner;

public class 公交车计费 {

	/**
	 * �������� 0.002 2.6 4 ������� 6.00 6.00 7.40
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Input();
	}

	public static void Input() {
		Scanner input = new Scanner(System.in);
		while (input.hasNext()) {
			double a = input.nextDouble();
			TL(a);
		}
		input.close();
	}

	public static void TL(double a) {
		double money = 0;
		if (a <= 0) {
			money = 0;
		} else if (a <= 3) {
			money = 6;
		} else {
			money = 6 + (a - 3) * 1.4;
		}
		System.out.printf("%.2f\n", money);
	}
}
