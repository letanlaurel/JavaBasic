package tl6;

import java.util.Scanner;

public class 分段函数计算 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Input();
	}
	public static void Input() {
		Scanner input = new Scanner(System.in);
			double a = input.nextDouble();
			TL(a);
			input.close();
		
	}

	public static void TL(double x) {
		double y = 0;
		if (x < 1) {
			y = x;
		} else if (x < 10) {
			y = 2*x-1;
		} else {
			y = 3*x-11;
		}
		System.out.printf("%.6f\n", y);
	}

}
