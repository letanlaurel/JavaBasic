package tl6;

import java.util.Scanner;

public class 二分查找法 {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int arr [] = new int[N];
		for (int i = 0; i < N; i++) {
			arr[i] = input.nextInt();
		}
		System.out.println(find(input.nextInt(), arr));
		input.close();
	}
	public static int find(int c,int ... a) {
		int end = a.length-1;
		int start = 0;
		while(start <= end) {
			int avg = (end + start)/2;
			System.out.print(a[avg]+" ");
			if(c > a[avg]) {
				
				start = avg + 1;
			}
			else if(c < a[avg]) {
				end = avg - 1;
			}
			else {
				System.out.println();
				return avg + 1;//返回找到元素的下标 从1开始
			}
		}
		return -1;
	}
	
}
