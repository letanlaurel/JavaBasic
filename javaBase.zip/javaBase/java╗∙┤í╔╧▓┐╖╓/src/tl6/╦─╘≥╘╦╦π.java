package tl6;
import java.util.Scanner;
public class 四则运算 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		String str = sc.nextLine();
		for(int i=0;i<n;i++){
			str = sc.nextLine();
			sc.close();
			int loc = str.indexOf('+');
			String s[];
			if(loc>0){
				s = str.split("\\+");
				float a = Float.parseFloat(s[0]);
				float b = Float.parseFloat(s[1]);
				System.out.println(String.format("%.2f",a+b));
			}
			loc = str.indexOf('-');
			if(loc>0){
				s = str.split("\\-");
				float a = Float.parseFloat(s[0]);
				float b = Float.parseFloat(s[1]);
				System.out.println(String.format("%.2f",a-b));
			}
			loc = str.indexOf('*');
			if(loc>0){
				s = str.split("\\*");
				float a = Float.parseFloat(s[0]);
				float b = Float.parseFloat(s[1]);
				System.out.println(String.format("%.2f",a*b));
			}
			loc = str.indexOf('/');
			if(loc>0){
				s = str.split("\\/");
				float a = Float.parseFloat(s[0]);
				float b = Float.parseFloat(s[1]);
				System.out.println(String.format("%.2f",a/b));
			}
			loc = str.indexOf('%');
			if(loc>0){
				s = str.split("\\%");
				Integer a = Integer.parseInt(s[0]);
				Integer b = Integer.parseInt(s[1]);
				System.out.println(a%b);
			}
		}
	}

}