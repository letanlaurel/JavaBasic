package tl6;

import java.util.Scanner;

public class 测试 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Input();
	}
	public static void Input() {
		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		String str = input.nextLine();//�����س�
		for (int i = 0; i < N; i++) {
			str = input.next();
			TL(str);
		}
		input.close();
	}
	public static void TL(String str){
		String []a;
//		if(str.indexOf('-')==0 && str.lastIndexOf('-')==1){
//			String s1 = str.substring(0,2);
//			String s2 = str.substring(3,str.length());
//			System.out.printf("%.2f\n",Double.valueOf(s1)-Double.valueOf(s2));
//		}
		int k = str.indexOf('+');
		if(k>0){
			a = str.split("[+]");
			System.out.printf("%.2f",Double.valueOf(a[0])+Double.valueOf(a[1]));
		} k = str.indexOf('*');
		if(k>0){
			a = str.split("[*]");
			System.out.printf("%.2f",Double.valueOf(a[0])*Double.valueOf(a[1]));
		} k = str.indexOf('/');
		if(k>0){
			a = str.split("[/]");
			System.out.printf("%.2f",Double.valueOf(a[0])/Double.valueOf(a[1]));
		} k = str.indexOf('%');
		if(k>0){
			a = str.split("[%]");
			System.out.printf("%d",Integer.valueOf(a[0])%Integer.valueOf(a[1]));
		} k = str.indexOf('-');
		if(k>0){
			a = str.split("[-]");
			System.out.printf("%.2f",Double.valueOf(a[0])-Double.valueOf(a[1]));
		}
		
	}

}
