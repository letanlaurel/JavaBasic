package tl6;

import java.util.Scanner;

public class 提取字符串中的数字 {

	/**��ȡ�ַ����е�����
	 * @param args
	 */
	public static void main(String[] args) {
		Input();
	}
	public static void Input(){
		Scanner input = new Scanner(System.in);
		while(input.hasNext()){
		String str = input.nextLine();
		str = str.replaceAll("\\D", "");
		System.out.println(str);
		}
		input.close();
	}

}
