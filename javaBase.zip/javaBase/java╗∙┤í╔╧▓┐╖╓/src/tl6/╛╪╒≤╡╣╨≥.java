package tl6;

import java.util.Scanner;

public class 矩阵倒序{

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Input();
	}
	public static void Input(){
		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int [][] a = new int [N][N];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				a[i][j] = input.nextInt();
			}
		}
		Output(a);
		input.close();
	}
	public static void Output(int a[][]){
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				System.out.print(a[j][i] + " ");
			}
			System.out.println();
		}
	}

}
