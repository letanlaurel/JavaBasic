package tl6;

/*
 * 6 、(100分)快速排序
快速排序的核心操作是划分，通过某个数据将原来排序表分成两部分，前面部分比该数小，后面数据比该数据大或相等，该位置就为某数据排序后的位置，即该数据完成排序。如果定义一个排序表的划分方法为：
      int partition(int[] R,int low,int high);     其中，low,high表示将数据R的第low个数据到high个数据进行划分，返回到整数为划分后到支点存储的位置；快速排序在查找分支点位置的方法有多种，本题目的排序过程中，首先从右向左移动，搜索小于分支记录的第一个元素，再从左向右移动，搜索大于分支记录的第一个元素，交互该两个记录值，继续搜索，直到两个搜索点交汇，如果交汇点记录与分支记录相等，分支记录与交汇点数据不交换，分支位置为交汇位置; 完成划分方法后，通过递归调用完成快速排序：
     void QuickSort(int[] R,int s,int t){
           if(s<t){
              int i=partition(R,s,t);
              QuickSort(R,s,i-1);
               QuickSort(R,i+1,t);
          }
     }
     建议每次划分选择第一个元素为支点记录进行编程。给你到问题是，将标准输入的n个整数采用快速排序，并需要显示出每次划分分支点存储的位置，第一个数为0，分支点的输出顺序按照程序递归产生的分支点的先后进行输出，并完成该数据的排序。
输入：标准输入，输入的第一行为整数的个数n值，第二行为n个整数，每个整数之间为一个空格。
输出：标准输出，输出的第一行依次输出排序过程中使用的支点位置，每个输出数据之间使用一个空格隔开,第二行输出排序后的序列，每个输出数据之间使用一个空格隔开。
输入样例：
14
39 80 76 41 13 29 50 78 30 11 100 7 41 86
输出样例：
5 3 2 1 8 7 9 13 12 10
7 11 13 29 30 39 41 41 50 76 78 80 86 100
 */

import java.util.Scanner;

public class Temp1 {

	public static void main(String[] args) {
		/*Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int arr [] = new int[N];
		for (int i = 0; i < N; i++) {
			arr[i] = input.nextInt();
		}*/
		int arr[] = { 3,9,5,2,3 };
		//input.close();
		quicksort(arr);
		//fenqu(arr,0,arr.length-1);
		System.out.println();
		for (int i : arr) {
			System.out.print(i+" ");
		}
	}

	public static void quicksort(int[] arr) {
		int start = 0;// 开始位置
		int end = arr.length - 1; // 末尾位置
		quicksort(arr, start, end);
	}

	private static void quicksort(int[] arr, int start, int end) {
		if (start < end) {
			int index = fenqu(arr, start, end);
			quicksort(arr, start, index - 1);//左边区域
			quicksort(arr, index + 1, end);//右边区域
		}
	}
	/**
	 * 分区
	 * @param arr
	 * @param start
	 * @param end
	 * @return 支点值
	 */
	private static int fenqu(int[] arr, int start, int end) {
		int temp;
		int i = start+1;
		int j = end;
		int x = arr[start]; // 基准值
		
		while (i < j) {
			while (arr[j] >= x && i < j) {
				j--;
			}
			//System.out.println("j--------------"+j);
//			if (i < j) {
//				arr[i] = arr[j];
//				i++;
//			}
			while (arr[i] < x && i < j) {
				i++;
			}
			//System.out.println("i--------------"+i);
			if (i < j) {
				//arr[j] = arr[i];
				//j--;
				temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				j--;
				i++;
			}
			
		}
		//System.out.println(start+" "+ i+"     "+j);
		if (arr[start]>= arr[j]){
			temp = arr[start];
			arr[start] = arr[j];
			arr[j] = temp;
			System.out.print(j + " ");
			return j;
		}
		else{
			System.out.print((start) + " ");
			return start;
		}
			
		
	}
}

