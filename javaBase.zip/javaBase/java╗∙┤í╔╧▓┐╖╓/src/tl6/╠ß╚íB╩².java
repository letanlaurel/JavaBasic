package tl6;

import java.util.Scanner;

public class 提取B数 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Input();
	}
	public static void Input() {
		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		String str = input.nextLine();//�����س�
		for (int i = 0; i < N; i++) {
			str = input.nextLine();
			TL(str);
		}
		input.close();
	}
	public static void TL(String str){
		str = str.replaceAll("\\D"," ");
		while(str.contains("  ")){
			str = str.replaceAll("  ", " ");
		}
		str = str.trim();
		String []a = str.split(" ");
		for (int i = 0; i < a.length; i++) {
			if(a[i].equals("")){
				System.out.println("NO");
			}else{
			System.out.println(a[i]);
			}
		}
	}

}