package tl6;

import java.util.Scanner;

public class 混球问题 {
	public static final double PI = 3.14;

	/**
	 * ����뾶 ������������ ���
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Input();
	}

	public static void Input() {
		Scanner input = new Scanner(System.in);
		double R = input.nextDouble();
		TL(R);
		input.close();
	}

	public static void TL(double R) {
		double S = 0;
		double V = 0;
		double s = 0;
		S = 4 * PI * R * R;
		V = 4.0 / 3 * PI * Math.pow(R, 3);
		s = PI * R * R;
		System.out.printf("%.2f %.2f %.2f\n", S, V, s);
	}

}
