package tl6;

import java.util.Scanner;

public class 成绩问题{

	/**��������
		90 85 90
		�������
		265
		88.33
	 * @param args
	 */
	public static void main(String[] args) {
			Input();
	}
	public static void Input(){
		Scanner input = new Scanner(System.in);
		int a = input.nextInt();
		int b = input.nextInt();
		int c = input.nextInt();
		TL(a,b,c);
		input.close();
	}
	public static void TL(int ...a){
		int score = 0;
		for (int i = 0; i < a.length; i++) {
			score += a[i];
		}
		System.out.printf("%d\n%.2f\n",score,score*1.0/a.length);
	}
}
