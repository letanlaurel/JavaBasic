
public class TLtiaoshi {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a[][] = {{1,2,3},{4,4,4},{2,2,3}};
		int k = 0,t =0,max = 0,min = 0;
		for (int i = 0; i < a.length; i++) {
			max = a[i][0];
			for (int j = 1; j < a.length; j++) {
				if(max<a[i][j]){
					max = a[i][j];
					k = i;t = j;
				}
			}min = a[0][t];
			for (int j = 1; j < a.length; j++) {
				if(min>a[j][t]){
					min = a[j][t];
				}
			}
			if(min == max)
			{
				System.out.printf("%d,%d;",k+1,t+1);
				
			}
		}
	}
	}
// 1 6 3 5 4
// 