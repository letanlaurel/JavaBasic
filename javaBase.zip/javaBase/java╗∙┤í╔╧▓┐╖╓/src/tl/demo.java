package tl;

import java.util.Scanner;

public class demo {

	/**
	 * ������ת
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Input();
	}

	/** �������� */
	public static void Input() {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		int a[][] = new int[n][n];
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				a[i][j] = input.nextInt();
			}
		}
		TL(a);
		input.close();
	}

	/** ���е������ */
	public static void TL(int a[][]) {
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				System.out.print(a[j][i] + " ");
			}
			System.out.println();
		}
	}
}
