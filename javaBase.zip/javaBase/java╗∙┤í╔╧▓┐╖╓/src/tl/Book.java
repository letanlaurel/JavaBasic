package tl;

public class Book {
	private String book;
	private String id;
	private int count;
	public boolean isborrow;
	
	public Book() {
		super();
	}

	public Book(String book, String id, int count, boolean isborrow) {
		super();
		setBook(book);
		setBorrow(isborrow);
		setCount(count);
		setId(id);
	}

	public String getBook() {
		return book;
	}

	public void setBook(String book) {
		this.book = book;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		if(count<0){
			count = 0;
			System.err.println("������������ϵͳ����棡��");
		}
		if(isborrow && count>=0){
			this.count = count;
		}
			
	}

	public boolean isBorrow() {
		return isborrow;
	}

	public void setBorrow(boolean isborrow) {
		if(!isborrow){
			isborrow = false;
			System.err.println("���鲻��������");
		}
		this.isborrow = isborrow;
	}
	
	
	
}
