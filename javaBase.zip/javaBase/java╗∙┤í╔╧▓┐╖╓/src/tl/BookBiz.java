package tl;

public class BookBiz {
	public void Booksell(Book book,int n){
		book.setCount(book.getCount()-n);
		Pandun(book);
	}
public void Pandun(Book book){
	if(book.isborrow && book.getCount()>=0){
		System.out.println("��ǰ��Ŀ��Ϊ��"+book.getCount());
	}
}
}
