package Javatest1;

import java.util.Arrays;
import java.util.Scanner;

public class paixu {

	/**����
	 * ��������
	 * 6
	 * 7 7 7 5 8 8
	 * �������
	 * 5 7 8
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		int N =input.nextInt();
		int [] a = new int [N];
		for (int i = 0; i < a.length; i++) {
			a[i]=input.nextInt();
		}
		input.close();
		Arrays.sort(a);
		for (int i = 0; i < a.length; i++) {
			System.out.print(a[i]+" ");
		}
		System.out.println();
		int []b = new int[N];
		
		b[0] = a[0];
		int j=1;
		for (int i = 1; i < a.length; i++) {
			if(a[i-1]!=a[i]){
				b[j]= a[i];
				j++;
			}			
		}
		for (int i = 0; i < j-1; i++) {
			System.out.print(b[i]+" ");
		}
		System.out.println(b[j-1]);
	}

}
