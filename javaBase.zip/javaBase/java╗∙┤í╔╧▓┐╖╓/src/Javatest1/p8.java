package Javatest1;

import java.util.Scanner;

public class p8 {
	public static void main(String args[]) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		in.close();
		for (int i = 0; i < n; i++) {
			int w = 1;
			int k = in.nextInt();
			int arr[][] = new int[k][k];
			for (int m = 0; m < k; m++) {
				for (int b = 0; b < k; b++)
					arr[m][b] = in.nextInt();
			}
			int L = 0;
			for (int m = 0; m < k; m++) {
				int max = arr[m][0];
				for (int b = 0; b < k; b++) {
					if (arr[m][b] > max) {
						max = arr[m][b];
						L = b;
					}
				}
				int min = arr[m][L];
				for (int b = 0; b < k; b++) {
					if (arr[m][L] > arr[b][L])
						min = arr[b][L];
				}
				if (min == max) {
					System.out.print((m + 1) + "," + (L + 1) + ";");
					w = 0;
				}
			}
			if (w == 1) {
				System.out.println("NO;");
			} else {
				System.out.println();
			}
		}
	}
}