package Javatest1;

import java.util.Scanner;

public class MyMath {
	public static double trianglearea(double a, double b, double c)
			throws NotTriAngleException, NegativeArgementsException {
		// �ж�a,b,c�Ƿ�ȫΪ ����
		if (a < 0 || b < 0 || c < 0) {
			throw new NegativeArgementsException("Negative Argements");
		}
		// �ж�a,b,c�Ƿ��ܹ���������
		if (a + b <= c || a + c <= b || c + b <= a) {
			throw new NotTriAngleException("Not TriAngle");
		}
		// �������������
		double p = (a + b + c) / 2.0;
		double s = Math.sqrt(p * (p - a) * (p - b) * (p - c));
		return s;
	}

	public static void main(String[] args) {
		double a = 0, b = 0, c = 0;
		int N;
		Scanner sc = new Scanner(System.in);
		N = sc.nextInt();
		sc.close();
		for (int i = 0; i < N; i++) {
			try {
				a = sc.nextDouble();
				b = sc.nextDouble();
				c = sc.nextDouble();
				System.out.printf("%.2f\n", MyMath.trianglearea(a, b, c));
			} catch (NegativeArgementsException e) {
				System.out.println(e.getMessage());
			} catch (NotTriAngleException e) {
				System.out.println(e.getMessage());
			} catch (Exception e) {
			}
		}
	}
}

@SuppressWarnings("serial")
class NotTriAngleException extends Exception {
	NotTriAngleException(String message) {
		super(message);
	}
}

@SuppressWarnings("serial")
class NegativeArgementsException extends Exception {

	NegativeArgementsException(String message) {
		super(message);
	}
}