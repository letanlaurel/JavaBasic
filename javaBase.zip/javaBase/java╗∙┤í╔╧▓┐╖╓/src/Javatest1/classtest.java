package Javatest1;

public class classtest {

	/**������
	 * @param args
	 */
	public static void main(String[] args) {
		areaclass tl = new areaclass(2);
		//tl.setR(2);
		tl.Get();

	}

}
