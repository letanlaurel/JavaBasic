package Javatest1;

public class areaclass {

	private double r ;
	private double l ;
	private double s ;
	public areaclass(){}
	public areaclass(double r){
		this.setR(r);
	}
	public void setR(double r) {
		this.r = r;
	}
	public double getL() {
		l = 2 * Math.PI*r;
		return l;
	}
	public double getS() {
		s = Math.PI*Math.pow(r, 2);
		return s;
	}
	public void Get(){
		getL();
		getS();
		System.out.println("Բ�������"+s);
		System.out.println("Բ���ܳ���"+l);
	}
}
