package Javatest1;
import java.util.Scanner;

public class cheshiaaa {
	/**
	 * ��������
	 * 
	 * �����������룺 2 2 1 3 3 4 3 1 2 3 4 4 4 2 2 3 ����������� 1,2; 1,3;3,3;
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Input();
	}

	public static void Input() {
		Scanner input = new Scanner(System.in 

);
		int n = input.nextInt();
		for (int k = 0; k < n; k++) {
			int N = input.nextInt();
			int[][] a = new int[N][N];
			for (int i = 0; i < N; i++) {
				for (int j = 0; j < N; j++) {
					a[i][j] = input.nextInt();
				}
			}
			TLfound(a,N);
			input.close();
		}
	}

	public static void TLfound(int a[][],int N) {
		int kr,t,kc,max,min;  //ĳ�����ֵ�±�[kr,t],��Ӧ����Сֵ�±�[kc,t]
		boolean l = false;
		for (int i = 0; i < N; i++) {
			max = a[i][0];
			kr=i;
			t=0;
			for (int j = 1; j < N; j++) {
				if (max < a[i][j]) {
					max = a[i][j];
					kr = i;
					t = j;
				}
			}
			//Ŀǰ������ֵ�±�[kr,t]
			kc=kr;
			min = a[kr][t];
			for (int j = 0; j < a.length; j++) {
				if (min > a[j][t]) {
					min = a[j][t];
					kc = j;
				}
			}
			if (kr == kc) {
				System.out.printf("%d,%d;", kr + 1, t + 1);
				l = true;
			}
		}
		if (!l) {
			System.out.println("NO");
		}
		else
			System.out.println();
	}
}
