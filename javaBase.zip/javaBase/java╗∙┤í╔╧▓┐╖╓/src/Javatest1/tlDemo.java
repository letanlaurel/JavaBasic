package Javatest1;

import java.util.Scanner;

public class tlDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		String str = new Scanner(System.in).nextLine();
		tldemo(str);
	}
	public static void tldemo(String str){
		String []str1=str.split(" ");
		for (int i = 0; i < str1.length; i++) {
			System.out.println(str1[i]);
		}	
	}

}
