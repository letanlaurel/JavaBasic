package com.tl666.examtest;

public class InsertSrotTest {
	public static void main(String[] args) {
		for (int i : insertsrot(new int[] { 1, 9, 3, 6, 8, 7, 2, 5, 4 }))
			System.out.print(i + " ");
	}

	private static int[] insertsrot(int... arr) {
		int index = -1;
		int key = 0;
		int n = arr.length;
		for (int i = 1; i < n; i++) {
			key = arr[i];
			index = i - 1;
			while (key < arr[index] && 0 <= index) {
				arr[index + 1] = arr[index];
				index--;
			}
			arr[index + 1] = key;
		}
		return arr;
	}

}
