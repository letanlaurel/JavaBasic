package com.tl666.examtest;

public class QuickSortTest {

		public static void main(String[] args) {
//			Scanner input = new Scanner(System.in);
//			int N = input.nextInt();
//			int arr [] = new int[N];
//			for (int i = 0; i < N; i++) {
//				arr[i] = input.nextInt();
//			}
			//int arr[] = { 39, 80, 76, 41, 13, 29, 50, 78, 30, 11, 100, 7, 41, 86 };
			int arr[] = { 41, 13, 29, 50, 78, 30, 11, 100, 7, 41, 86 };
			//input.close();
			quicksort(arr);
			System.out.println();
			for (int i : arr) {
				System.out.print(i+" ");
			}
		}

		public static void quicksort(int[] arr) {
			int start = 0;// 开始位置
			int end = arr.length - 1; // 末尾位置
			quicksort(arr, start, end);
		}

		private static void quicksort(int[] arr, int start, int end) {
			if (start < end) {
				int index = fenqu(arr, start, end);
				quicksort(arr, start, index - 1);//左边区域
				quicksort(arr, index + 1, end);//右边区域
			}
		}
		/**
		 * 分区
		 * @param arr
		 * @param start
		 * @param end
		 * @return 支点值
		 */
		private static int fenqu(int[] arr, int start, int end) {
			int temp;
			int i = start+1;
			int j = end;
			int x = arr[start]; // 基准值
			while (i < j) {
				while (arr[j] >= x && i < j) {
					j--;
				}
				while (arr[i] < x && i < j) {
					i++;
				}
				if (i < j) {
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
					j--;
					i++;
				}
			}
			System.out.println( start +"--"+i+"**"+i);
			if (arr[start]>=arr[j]){
				temp = arr[start];
				arr[start] = arr[j];
				arr[j] = temp;
				System.out.print(j + " ");
				return j;
			}else{
				System.out.print(start + " ");
				return start;
			}
		}
	}

