import java.util.Scanner;
/**
 * 
 * @author 19760
 *
 */
public class Triangle{
	public static void main(String[] args) {
		System.out.println("������Ҫ����������θ�����");
		Input();
	}
	public static void Input()throws IllegalArgumentException{
		@SuppressWarnings("resource")
		Scanner input = new Scanner(System.in);
		try {
				int N = input.nextInt();
				System.out.println("�����������εı߳���");
					double a = 0;
					double b = 0;
					double c = 0;
		for (int i = 0; i < N; i++) {
			a = input.nextDouble();
			b = input.nextDouble();
			c = input.nextDouble();
		if(a+b>c && b+c>a && a+c>b&&a*b*c!=0){
				TL tl = new TL(a,b,c);
				tl.TLget();
		}
		else if(a*b*c>=0){
			throw new IllegalArgumentException("Not TriAngle");
		}else{
			throw new IllegalArgumentException("Negative Argements");
		}
	}
			} catch (IllegalArgumentException e) {
				System.err.println(e.getMessage());
			}	
	}
}
class TL{
	private double a;
	private double b;
	private double c;
	private double s;
	private double p;
	public TL(){
		
	}
	public TL(double a , double b, double c){
		this.setA(a);
		this.setB(b);
		this.setC(c);
	}
	public void setA(double a) {
		this.a = a;
	}
	public void setB(double b) {
		this.b = b;
	}
	public void setC(double c) {
		this.c = c;
	}
	public double getS(){
		p = (a+b+c)/2;
		s = Math.sqrt(p*(p-a)*(p-b)*(p-c));
		return s;
	}
	public void TLget(){
		getS();
		System.out.printf("�����ε����Ϊ��%.2f\n",s);
	}
}