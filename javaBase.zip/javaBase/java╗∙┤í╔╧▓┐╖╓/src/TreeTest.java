
import java.util.LinkedList;
import java.util.Scanner;
import ds.tree.LinkBiTree;
import ds.tree.LinkNode;

public class TreeTest {
	public static void main(String[] args) {
		LinkBiTree<Character> tree = new LinkBiTree<Character>();
		LinkBiTree.create(tree);
		Show(tree);
	}

	public static void Show(LinkBiTree<Character> tree) {
		Scanner input = new Scanner(System.in);
		int n = input.nextInt();
		switch (n) {
		case 1:
			PreOrder(tree.root);
			System.out.println();
			break;
		case 2:
			InOrder(tree.root);
			System.out.println();
			break;
		case 3:
			PostOrder(tree.root);
			System.out.println();
			break;
		case 4:
			levelOrder(tree.root);
			System.out.println();
			break;
		default:
			break;
		}
		Show(tree);
		input.close();
	}

	public static void PreOrder(LinkNode<Character> root) { // 先序遍历
		if (root != null) {
			System.out.print(root.data + " ");
			PreOrder(root.lchild);
			PreOrder(root.rchild);
		}
	}

	public static void InOrder(LinkNode<Character> root) { // 中序遍历
		if (root != null) {
			InOrder(root.lchild);
			System.out.print(root.data + " ");
			InOrder(root.rchild);
		}
	}

	public static void PostOrder(LinkNode<Character> root) { // 后序遍历
		if (root != null) {
			PostOrder(root.lchild);
			PostOrder(root.rchild);
			System.out.print(root.data + " ");
		}
	}

	public static void levelOrder(LinkNode<Character> root) {// 层次遍历
		if (root != null) {
			LinkedList<LinkNode<Character>> queue = new LinkedList<>();
			LinkNode<Character> c = null;
			queue.offer(root);// 根节点入队
			while (!queue.isEmpty()) {
				c = queue.poll();
				System.out.print(c.data + " ");
				if (c.lchild != null)
					queue.offer(c.lchild);
				if (c.rchild != null)
					queue.offer(c.rchild);
			}

		}
	}
}