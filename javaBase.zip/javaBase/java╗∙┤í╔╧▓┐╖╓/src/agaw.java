import java.util.ArrayList;

public class agaw {
	public int getNum(int n){
		/********* Begin *********/
        int s = 0;
		while(n != 0){
			if(n % 2 == 0){
            	n = n/2;
            }else {
            	n = n - 1;
            	s++;
            }
        }
		return s;
		/********* End *********/
	}
	public static void getNum1(int[][] matrix){
		/********* Begin *********/
		ArrayList<Integer> lt = new ArrayList<>();
        for (int i = 0; i < matrix.length; i++) {
			for (int j = matrix.length - 1; j >= 0; j--) {
				lt.add(matrix[j][i]);
				System.out.print(matrix[j][i]+" ");
			}
			System.out.println();
		}
        int t = 0;
        for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				matrix[i][j] = lt.get(t);
				t++;
			}
		}
        System.out.println("-----------------------------------");
        for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix.length; j++) {
				System.out.print(matrix[i][j]+" ");
			}
			System.out.println();
		}
		/********* End *********/
	}
	public static void main(String[] args) {
		getNum1(new int [][]{{1,2,3},{4,5,6},{7,8,9}});
	}
}
/**
 * 1 2 3
 * 4 5 6
 * 7 8 9
 * 
 * 7 4 1 
 * 8 5 2
 * 9 6 3
 * */
