import java.util.Arrays;


public class paixu {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int [] str = new  int[100000];
		long starttime = System.currentTimeMillis(); 
		for (int i = 0; i < str.length; i++) {
			str[i]=(int)(Math.random()*100000);
		}
		Arrays.sort(str);
		long endtime = System.currentTimeMillis();
		System.out.println(endtime-starttime+"����");
	}

}
