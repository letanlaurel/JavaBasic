import java.util.Arrays;
import java.util.Scanner;
public class paixufa {

	/**����
	 * @param args
	 */
	public static void main(String[] args) {
		final int N = 3;
		int []str = new int[N];
		for (int i = 0; i < str.length; i++) {
			str[i] = new Scanner(System.in).nextInt();
		}
		Arrays.sort(str);
		for (int i = 0; i < str.length; i++) {
			System.out.print(str[i]+",");
		}
		System.out.println();
	}

}
