package com.tl666.node;

public interface Itable<E> {
	/**
	 * 往末尾添加元素
	 * 
	 * @return
	 */
	boolean add(E item);

	/**
	 * 插入元素
	 * 
	 * @param i
	 * @param item
	 * @return
	 */
	boolean add(int i, E item);

	/**
	 * 删除元素
	 * 
	 * @param i
	 * @return
	 */
	E delete(int i);

	/**
	 * 查找指定元素的位置
	 * 
	 * @return
	 */
	int indexOf(E item);

	/**
	 * 通过索引得到元素
	 * 
	 * @param i
	 * @return
	 */
	E get(int i);

	/**
	 * 获取线性表的长度
	 * 
	 * @return
	 */
	int size();

	/**
	 * 清空线性表
	 * 
	 * @return
	 */
	void clear();

	/**
	 * 判断线性表是否为空
	 * 
	 * @return
	 */
	boolean isEmpty();

}
