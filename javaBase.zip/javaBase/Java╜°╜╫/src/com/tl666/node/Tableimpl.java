package com.tl666.node;

public class Tableimpl<E> implements Itable<E> {
	private Node<E> start; // 线性表的头指针
	private int size; // 线性表的长度
	// 定义一个保存数据的内部类

	private static class Node<E> {
		E item; // 要添加的元素
		Node<E> next;// 下一个节点

		public Node(E item, Node<E> next) {
			this.item = item;
			this.next = next;
		}

		// 重写了Object的toString方法 便于做测试
		@Override
		public String toString() {
			return "item=" + item + ", next=" + next;
		}

	}

	public Tableimpl() {// 实例化对象的时候就把头指针初始化为null
		start = null;
	}

	// 重写了Object的toString方法 便于做测试
	@Override
	public String toString() {
		return "Tableimpl [start=" + start + ", size=" + size + "]";
	}

	@Override
	public boolean add(E item) {
		if (start == null) {// 表示还没有元素
			start = new Node<E>(item, null);// 往第一个位置添加一个元素
		} else {
			Node<E> c = start; // 定义一个节点来保存头指针
			while (c.next != null) {
				c = c.next;// 把指针移动到链表的末尾
			}
			c.next = new Node<E>(item, null);// 表示往末尾添加元素
		}
		size++;// 每添加一个元素 长度加一
		return true;
	}

	@Override
	public boolean add(int i, E item) {
		Node<E> c = null; // 定义一个节点来保存头指针 然后进行移动
		Node<E> p = null; // 定义一个节点来保存元素添加的位置
		if (i < 0 || i > size) {// 判断输入的所有是否合法
			return false;
		}
		Node<E> newnode = new Node<E>(item, null);// 实例化一个添加元素的对象
		if (i == 0) {// 判断是否往第一个元素前面添加元素
			newnode.next = start;// 把头指针赋值给该元素的下一位
			start = newnode; // 把该节点变成头指针
			size++;// 链表长度加一
		} else {
			c = start;// 保存头指针
			int j = 0;// 定义一个变量用来保证指针移动的位置不超过要添加元素的位置
			while (c.next != null && j < i) {
				p = c;// 保存移动的值
				c = c.next;// 移动头指针
				j++;
			}
			if (i == j) {
				// Node<E> s = p.next;
				p.next = newnode;// 往该位置添加元素p.next == c
				newnode.next = c;// 把c的的值给新添加的元素的下一个指针
				size++;// 链表长度加一
			}

		}
		return true;
	}

	@Override
	public E delete(int i) {
		Node<E> c = null;
		E old = null;
		if (isEmpty() || i < 0 || i > size) {
			return old;
		}
		c = start; // 用c保存头指针 便于后面的移动
		if (i == 0) {
			old = c.item;// 把c指向的这个元素删除并且传给要删除的这个元素
			start = c.next; // 把头指针置于下一位
			size--; // 删除完成后长度减一
		} else {
			int j = 1;// 由于j是从1开始 c = start 所有 这里循环要多一次 j <= i
			Node<E> p = null;
			while (c.next != null && j <= i) {
				p = c;
				c = c.next;// 移动指针
				j++;
			}
			p.next = c.next;// p.next = c
			old = c.item;// 把c指向的这个元素删除并且传给要删除的这个元素
			c = null; // 出于安全考虑 把使用完的指针置为空
			size--; // 删除完成后长度减一
		}
		return old;
	}

	@Override
	public int indexOf(E item) {
		if (!isEmpty()) {
			Node<E> c = start; // 用c保存头指针 便于后面的移动
			int j = 0;// 记录下标
			while (c != null) {// 对链表进行遍历
				if (item.equals(c.item)) // 进行条件判断
					return j;// 如果找到就返回该元素的下标
				c = c.next; // 移动指针
				j++;// 链表长度加一
			}

		}
		return -1; // 没找到就返回负一
	}

	@Override
	public E get(int i) {
		if (isEmpty() || i < 0 || i > size) {// 判断输入是否合法
			return null;
		} else {
			Node<E> c = start; // 保存头指针
			int j = 0;// 记录下标
			while (c.next != null && j < i) {// 进行遍历
				c = c.next;
				j++;
			}
			if (i == j) {
				return c.item; // 匹配到下标就返回该下标对应的元素
			}
		}
		return null;
	}

	@Override
	public int size() {
		return size;// 返回链表的长度
	}

	@Override
	public void clear() {
		// 遍历链表 将里面所有数据设为空
		for (Node<E> c = start; c != null;c = c.next) {
			c.item = null;
			c.next = null;
		}
		start = null;// 头指针设为空
		size = 0; // 长度设为0
	}

	@Override
	public boolean isEmpty() {
		return size == 0; // 判断链表长度是否为空来判断链表是否为空
	}

}
