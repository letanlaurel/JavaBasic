package com.tl666.node;

import java.util.Scanner;

/**
 * 测试类
 * 
 * @author 19760
 *
 */
public class TableTest {
	@SuppressWarnings("rawtypes")
	static Tableimpl t = new Tableimpl<>();
	public static void main(String[] args) {
		SX();	
	}
	public static void CD() {
		System.err.println("请选择：");
		System.err.println("**************************************************");
		System.err.println("1.往末尾添加元素");
		System.err.println("2.根据下标插入元素");
		System.err.println("3.根据下标修改元素");
		System.err.println("4.根据下标获取元素");
		System.err.println("5.根据下标删除元素");
		System.err.println("6.根据元素得到下标");
		System.err.println("7.获取链表的长度");
		System.err.println("8.清空链表");
		System.err.println("9.获取链表的内容");
		System.err.println("10.退出系统");
		System.err.println("**************************************************");
	}
	@SuppressWarnings("unchecked")
	public static void SX() {
		CD();
		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
			switch (N) {
			case 1:
				System.out.print("请输入要添加的元素：");
				if(t.add(input.next())) {
					System.out.println("添加成功！！");
					break;
				}
				System.out.println("添加失败！！");
				break;
			case 2:
				System.out.print("请输入要插入的下标和元素：");
				if(t.add(input.nextInt(), input.next())) {
					System.out.println("添加成功！！");
					break;
				}
				System.out.println("添加失败！！");
				break;
			case 3:
				System.out.print("请输入要修改的元素的下标和元素：");
				break;
			case 4:
				System.out.print("请输入要查找的元素的下标：");
				Object ob = t.get(input.nextInt());
				System.out.println("当前元素为："+ob);
				break;
			case 5:
				System.out.print("请输入要删除的元素的下标：");
				Object delete = t.delete(input.nextInt());
				System.out.println("删除元素："+delete+"成功！！");
				break;
			case 6:
				System.out.print("请输入要定位下标的元素：");
				int n = t.indexOf(input.next());
				System.out.println("当前元素在下标为"+n+"位置");
				break;
			case 7:
				System.out.println("链表的长度为：" + t.size());
				break;
				
			case 8:
				t.clear();
				System.out.println("清空链表成功！！");
				break;
			case 9:
				if (t.isEmpty()) {
					System.out.println("当前链表为空！");
					break;
				}
				System.out.println("当前链表内容为：" + t);
				break;
			case 10:
				System.err.println("退出系统成功！");
				input.close();
				System.exit(0);
				break;
			default:
				System.err.println("请选择合法的选项！！");
				SX();
			}
			SX();
		}

}
