package com.tl666.proxy;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class HireProxyImpl implements InvocationHandler{
		private Object obj;
		public HireProxyImpl(Object obj) {
			this.obj = obj;
		}
		
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		System.out.println("难受！");
		Object invoke = invoke(obj, method, args);
		System.out.println("舒服！");
		return invoke;
	}

}
