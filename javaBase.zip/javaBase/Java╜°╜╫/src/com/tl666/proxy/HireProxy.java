package com.tl666.proxy;

public class HireProxy implements IHire {
		@Override
		public void hier() {
			System.out.println("买房子！！");
		}
}
