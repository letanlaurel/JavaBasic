package com.tl666.proxy;

public interface IHire {
	void hier();
}
