package com.tl666.proxy;

import java.lang.reflect.Proxy;

public class HireTest {
		public static void main(String[] args) {
			IHire hh = new HireProxy();
			IHire he = (IHire) Proxy.newProxyInstance(hh.getClass().getClassLoader(), hh.getClass().getInterfaces(), new HireProxyImpl(hh));
			he.hier();
		}
}
