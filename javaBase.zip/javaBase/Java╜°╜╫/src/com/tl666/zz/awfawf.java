package com.tl666.zz;

import org.junit.Test;

public class awfawf {
	@Test
	public void test() {
		String str5 = "12345678910";
		if(str5.length()!=11 || !str5.matches("\\d+")) {
			System.out.println("agawgawg");
			return;
		}else {
			System.out.println("1321351");
		}
	}
}
