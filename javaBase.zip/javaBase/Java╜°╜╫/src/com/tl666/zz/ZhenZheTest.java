package com.tl666.zz;
/**
 * 正则表达式  详情api查看java.util.regex
 * @author 19760
 *
 */
public class ZhenZheTest {

	public static void main(String[] args) {
		System.out.println("123".matches("\\d+"));//判断一个字符串是否是纯数字
		System.out.println("abc".matches("\\d+"));
		System.out.println("abc".matches("abc"));
		System.out.println("a".matches("[abc]"));//[abc] 表示a  b  c  中的一个
		System.out.println("b".matches("[abc]"));
		System.out.println("dh".matches("[^abc]"));//[abc] 表示不是a  b  c  中的一个 必须是一个
		System.out.println("d".matches("[^abc]"));//[abc] 表示不是a  b  c  中的一个 必须是一个
		System.out.println("1".matches("[0-9]"));
		System.out.println("a".matches("[a-z]"));
		System.out.println("A".matches("[A-Z]"));
		System.out.println("b".matches("[A-Za-z]"));//由字母组成 大小写任意
		System.out.println("c".matches("[0-9]"));//表示[a-zA-Z_]
		System.out.println("123654".matches("\\d{6}"));
		System.out.println("0.1".matches("[0-9]+[.]?[0-9]+"));//?表示出现一次或者0次   +号表示至少出现一次
		//*表示任意出现任意次数     {n} 表示出现n次   {n,}表示至少出现n次  {n,m}表示n<=次数<=m
		//正则A正则B  中间没空格  表示匹配完正则A后立刻匹配正则B   正则A|正则B 表示A或B 出现一次
		//(正则) 按照一组正则进行处理
		System.out.println("-123.0".matches("[-]?[0-9]*[.][0-9]+"));//只能判断小数类型 不能判断整数
		System.out.println("-123.0".matches("(-?\\d+)(\\.\\d+)?"));//判断实数正则表达式
		
	}

}
