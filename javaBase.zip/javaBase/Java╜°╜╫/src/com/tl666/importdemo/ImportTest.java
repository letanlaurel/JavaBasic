package com.tl666.importdemo;

import static java.util.Arrays.*;//包的静态导入

public class ImportTest {

	public static void main(String[] args) {
		System.out.println(asList("123"));
		
	}

}
