package com.tl666.BinaryTree;

import java.util.Arrays;
/**
 * 16级的课程设计提纲的树
 * 	用时半天
 * @author QQ1976087502
 *
 */
public class BinaryTreeTest {
	public static void main(String[] args) {
		BinaryTree<Person> bt = new BinaryTree<>();
		bt.add(new Person("张三", 25));
		bt.add(new Person("李四", 18));
		bt.add(new Person("王五", 17));
		bt.add(new Person("赵六", 10));
		bt.add(new Person("刘七", 21));
		bt.add(new Person("茜茜", 23));
		bt.add(new Person("米米", 9));
		bt.add(new Person("老九", 20));
		bt.add(new Person("老五", 28));
		bt.add(new Person("老三", 26));
		bt.remove(new Person("张三", 25));
		// bt.remove(new Person("李四", 18));
		// bt.remove(new Person("王五", 17));
		// bt.remove(new Person("赵六", 10));
		// bt.remove(new Person("刘七", 21));
		// bt.remove(new Person("茜茜", 23));
		// bt.remove(new Person("米米", 9));
		// bt.remove(new Person("老九", 20));
		// bt.remove(new Person("老五", 28));
		// bt.remove(new Person("老三", 30));
		System.out.println(Arrays.toString(bt.toArray()));
		System.out.println(bt.getCount());
	}
}

/**
 * 实现二叉树的操作
 * 
 * @author 19760
 * @param <T> 要进行二叉树的实现
 */
class BinaryTree<T extends Comparable<T>> {// 上限是Comparble
	private class Node {// 定义一个节点内部类
		private Comparable<T> data; // 数据域
		private Node parent;// 父节点
		private Node left; // 左节点
		private Node right; // 右节点

		public Node(Comparable<T> data) {// 存放数据
			this.data = data;
		}

		@Override
		public String toString() {
			return "Node [data=" + data + ", parent=" + parent + ", left=" + left + ", right=" + right + "]";
		}

		/**
		 * 实现节点数据的适当位置的存储
		 * 
		 * @param newNode
		 */
		@SuppressWarnings("unchecked")
		public void addNode(Node newNode) {
			if (newNode.data.compareTo((T) this.data) <= 0) {// 进行比较 比当前节点 小
				if (this.left == null) { // 没有左子树
					this.left = newNode; // 保存左子树
					newNode.parent = this; // 保存父节点
				} else {
					this.left.addNode(newNode); // 递归调用
				}
			} else {
				if (this.right == null) {// 没有右子树
					this.right = newNode; // 保存右子树
					newNode.parent = this; // 保存父节点
				} else {
					this.right.addNode(newNode); // 递归调用
				}
			}
		}

		/**
		 * 实现所有数据获取处理 按照中序遍历的方式（左 中 右）
		 */
		public void toArrayNode() {
			if (this.left != null) {
				this.left.toArrayNode(); // 递归调用
			}
			BinaryTree.this.returnData[BinaryTree.this.foot++] = this.data;// 保存数据
			if (this.right != null)
				this.right.toArrayNode();
		}

		@SuppressWarnings("unchecked")
		public boolean containsNode(Comparable<T> data) {
			if (data.compareTo((T) this.data) == 0) {
				return true;
			} else if (data.compareTo((T) this.data) < 0) {
				if (this.left != null) {
					return this.left.containsNode(data);
				} else {
					return false;
				}
			} else {
				if (this.right != null) {
					return this.right.containsNode(data);
				} else {
					return false;
				}
			}
		}

		@SuppressWarnings("unchecked")
		public Node getRemoveNode(Comparable<T> data) {
			if (data.compareTo((T) this.data) == 0) {
				return this;
			} else if (data.compareTo((T) this.data) < 0) {
				if (this.left != null) {
					return this.left.getRemoveNode(data);
				} else {
					return null;
				}
			} else {
				if (this.right != null) {
					return this.right.getRemoveNode(data);
				} else {
					return null;
				}
			}
		}
	}

	// 以下为二叉树的功能实现分隔线-----------------------------------------------------
	private Node root; // 根节点
	private int count;
	private Object[] returnData; // 存放对象
	private int foot = 0; // 脚标

	public int getCount() {
		return count;
	}

	/**
	 * 进行数据的保存
	 * 
	 * @param data 要保存的数据内容
	 * @exception NullPointerException 保存数据为空时抛出异常
	 */
	public void add(Comparable<T> data) {
		if (data == null) {
			throw new NullPointerException("保存数据不能为空！");
		}
		// 所有的数据本身不具备有节点关系的匹配，那么一定要将其包装在Node类之中
		Node newNode = new Node(data); // 保存节点
		if (this.root == null) { // 现在没有根节点
			this.root = newNode; // 作为根节点
		} else { // 需要将其保存到一个合适的节点
			this.root.addNode(newNode); // 交由Node类进行处理
		}
		this.count++;
	}

	/**
	 * 将所有数据存放在一个数组中
	 * 
	 * @return 返回一个数据数组
	 */
	public Object[] toArray() {
		if (this.count == 0) {
			return null;
		}
		this.returnData = new Object[this.count]; // 为数组初始化
		this.root.toArrayNode();// 交给Node类处理
		return this.returnData;
	}

	public boolean contains(Comparable<T> data) {
		if (count == 0) {// 表示还没有数据
			return false;
		}
		return this.root.containsNode(data);
	}

	@SuppressWarnings("unchecked")
	public Node remove(Comparable<T> data) {
		if (this.contains(data)) {
			if (this.root == null) {
				return null;
			}
			if (this.root.data.compareTo((T) data) == 0) {
				Node mvNode = this.root.right;
				while (mvNode.left != null) {
					mvNode = mvNode.left;
				}
				mvNode.left = this.root.left;
				mvNode.right = this.root.right;
				mvNode.parent.left = null;
				this.root = mvNode;
			} else {
				Node rmNode = this.root.getRemoveNode(data);
				if (rmNode != null) {
					if (rmNode.left == null && rmNode.right == null) {
						if (rmNode.parent.left == rmNode) {
							rmNode.parent.left = null;
							rmNode.parent = null;
						} else {
							rmNode.parent.right = null;
							rmNode.parent = null;
						}
					} else if (rmNode.left == null && rmNode.right != null) {
						if (rmNode.parent.right == rmNode) {
							rmNode.parent.right = rmNode.right;
							rmNode.right.parent = rmNode.parent;
						} else {
							rmNode.parent.left = rmNode.right;
							rmNode.right.parent = rmNode.parent;
						}
					} else if (rmNode.left != null && rmNode.right == null) {
						if (rmNode.parent.right == rmNode) {
							rmNode.parent.right = rmNode.left;
							rmNode.left.parent = rmNode.parent;
						} else {
							rmNode.parent.left = rmNode.left;
							rmNode.left.parent = rmNode.parent.left;
						}

					} else {
						if (rmNode.parent.left == rmNode) {
							Node mvNode = rmNode.right;
							while (mvNode.left != null) {
								mvNode = mvNode.left;
							}
							rmNode.parent.left = mvNode;
							mvNode.parent.left = null;
							mvNode.parent = rmNode.parent;
							mvNode.right = rmNode.right;
							mvNode.left = rmNode.left;
						} else {
							Node mvNode = rmNode.right;
							while (mvNode.left != null) {
								mvNode = mvNode.left;
							}
							rmNode.parent.right = mvNode;
							mvNode.parent.right = null;
							mvNode.parent = rmNode.parent;
							mvNode.right = rmNode.right;
							mvNode.left = rmNode.left;
						}
					}
				}
				return rmNode;
			}
			this.count--;
		}
		return null;
	}
}

class Person implements Comparable<Person> {
	private String name;
	private int age;

	@Override
	public int compareTo(Person o) {
		return this.age - o.age; // 根据年龄大小进行比较
	}

	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}

	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]\n";
	}

}