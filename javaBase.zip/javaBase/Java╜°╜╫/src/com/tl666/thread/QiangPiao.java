package com.tl666.thread;

public class QiangPiao {

	public static void main(String[] args) {
		Myqp m = new Myqp();
		new Thread(m , "黄牛").start();
		new Thread(m , "乐歌歌").start();
		new Thread(m , "小明").start();
	}

}
class Myqp implements Runnable{
	public static int piao = 10;
	private int count;
	private int n;
	@Override
	public void run() {
		for (int i = 1; i < 20; i++) {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			
			if(this.Qp()<=0) {
				System.out.println("票已经被抢完！！");
				break;
			}
		}
		n = count++;
		if(piao == 0) {
			Prin(n);
		}
	}
	public void Prin(int n) {
		System.out.println(Thread.currentThread().getName()+":"+n);
	}
	
	public synchronized int Qp() {
			if(piao > 0) {
				System.out.println(Thread.currentThread().getName() + "抢到第"+piao--+"张票!");
				return piao;
			}
			return 0;
	}
}
//
///**
// * 模拟网络延时线程不安全 
// */
//public class Site implements Runnable {
//	private int count = 10; // 记录剩余票数
//	private int num = 0; // 记录买到第几张票
//	private boolean flag = false;  //记录是否售完
//
//	public void run() {
//		while (true) {
//			if(!sale()){
//			break;
//			}
//		}		
//	}
//	// 同步方法：卖票
//	public synchronized boolean sale() {	
//		if (count <= 0) {
//			return false;
//		}
//		// 第一步：修改数据
//		num++;
//		count--;
//		try {
//			Thread.sleep(500); // 模拟网络延时
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		// 第二步：显示信息
//		System.out.println(Thread.currentThread().getName() + "抢到第" + num
//				+ "张票，剩余" + count + "张票！");
//       if(Thread.currentThread().getName().equals("黄牛党")){
//    	   return false;
//       }
//       return true;
//        
//	}
//}
