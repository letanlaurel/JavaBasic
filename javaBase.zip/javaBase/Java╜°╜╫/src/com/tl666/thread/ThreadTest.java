package com.tl666.thread;
class Person extends Thread{
	private String name;
	private int age;
	public Person(String name, int age) {
		this.age = age;
		this.name  = name;
	}
	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println("我是:    "+this.name+"   我今年"+this.age);
		}
	}
	
}
public class ThreadTest {
	public static void main(String[] args) {
		Person p = new Person("张三", 18);
		Person p1 = new Person("李四", 19);
		Person p2 = new Person("王五", 22);
		p.start();
		p1.start();
		p2.start();
	}
	
	
}
