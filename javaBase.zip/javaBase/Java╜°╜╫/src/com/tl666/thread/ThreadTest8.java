package com.tl666.thread;

public class ThreadTest8{
	public static void main(String[] args) {
		B b = new B();
		new Thread(new A(b)).start();
		new Thread(new C(b)).start();
	}
}
/**
 *	 存放数据
 * @author 19760
 *
 */
class B{
	private String name;
	private String say;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSay() {
		return say;
	}
	public void setSay(String say) {
		this.say = say;
	}
}
/**
 * 	生产数据
 * 	乐哥哥  帅比
 * 	张三    丑逼
 * @author 19760
 *
 */
class A implements Runnable{
	private B b;
	public A(B b) {
		this.b = b;
	}
	@Override
	public void run() {
		for (int i = 0; i < 50; i++) {
			if(i%2 == 0) {
			this.b.setName("乐哥哥");
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			this.b.setSay("帅比");
			}
			else {
				this.b.setName("张三");
				try {
					Thread.sleep(300);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				this.b.setSay("丑逼");
			}
		}
	}
}
/**
 * 	消费数据
 * @author 19760
 *
 */
class C implements Runnable{
	private B b;
	public C(B b) {
		this.b = b;
	}
	@Override
	public void run() {
		for (int i = 0; i < 50; i++) {
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(this.b.getName()+"是个"+this.b.getSay());
		}
	}
	
}