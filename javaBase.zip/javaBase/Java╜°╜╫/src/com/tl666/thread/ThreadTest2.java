package com.tl666.thread;
//@FunctionalInterface
//public interface Runnable{
//	void run();
//}
class Mythread implements Runnable{

	@Override
	public void run() {
			System.out.println("线程A启动");
	}
	
}
public class ThreadTest2 {

	public static void main(String[] args) {
		new Thread(new Mythread()).start();//方式1
		//方式二 用匿名内部类实现
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				System.out.println("线程B启动");
				
			}
		}).start();
		//因为Runnable里面只有一个抽象方法且加了函数注解 所以可以lambda表达式来实现
		new Thread(() -> System.out.println("线程C启动")).start();
		
		
	}

}
