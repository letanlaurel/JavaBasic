package com.tl666.thread;

public class ThreadTest9 {
	public static void main(String[] args) {
		CDate d = new CDate();
		new Thread(new ShengC(d)).start();
		new Thread(new XiaoF(d)).start();
	}
}

/**
 * 存放数据
 * 
 * @author 19760
 *
 */
class CDate {
	private String name;
	private String say;

	public synchronized void set(String name, String say) {
		this.name = name;
		try {
			Thread.sleep(50);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		this.say = say;
	}

	public synchronized void get() {
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(this.name+" = "+this.say);
	}
}

/**
 * 生产数据 乐哥哥 帅比 张三 丑逼
 * 
 * @author 19760
 *
 */
class ShengC implements Runnable {
	private CDate d;

	public ShengC(CDate d) {
		this.d = d;
	}

	@Override
	public void run() {
		for (int i = 0; i < 50; i++) {
			if (i % 2 == 0) {
				this.d.set("乐歌歌", "帅比");
			} else {
				this.d.set("张三", "丑比");
			}
		}
	}
}

/**
 * 	消费数据
 * @author 19760
 *
 */
class XiaoF implements Runnable{
	private CDate d;
	public XiaoF(CDate d) {
		this.d = d;
	}
	@Override
	public void run() {
		for (int i = 0; i < 50; i++) {
			this.d.get();
		}
	}
	
}