package com.tl666.thread;

public class ThreadTest5 {
	public static void main(String[] args) {
		Myssthread td = new Myssthread();
		Thread t1 = new Thread(td );
		Thread t2 = new Thread(td );
		Thread t3 = new Thread(td );
		t1.setPriority(Thread.MIN_PRIORITY);//设置线程优先级最低优先级 注意：设置优先级可能往前面执行  是可能 概率高一点
		t2.setPriority(Thread.NORM_PRIORITY);//中等优先级
		t3.setPriority(Thread.MAX_PRIORITY);//最高优先级
		t1.start();
		t2.start();
		t3.start();
		
		
		
	}
}
class Myssthread implements Runnable{

	@Override
	public void run() {
		for (int i = 0; i < 10; i++) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName()+":执行"+i);
		}		
	}
	
}