package com.tl666.thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ThreadPoolTest {

	public static void main(String[] args)throws Exception {
		//test();
//		test2();
//		test3();
		test4();
	}
	public static void test() {
		//现在创建一个模拟线程池  但是里面没有线程
		ExecutorService service = Executors.newCachedThreadPool();//无限大线程池
		for (int i = 0; i < 10; i++) {
			//Thread.sleep(200);
			int x = i;
			service.submit(() ->{
				System.out.println(Thread.currentThread().getName() +" ,"+ x);
			});
		}
		service.shutdown();//关闭线程池
	}
	
	public static void test2() {
		//现在创建一个模拟线程池  但是里面没有线程
		ExecutorService service = Executors.newSingleThreadExecutor();//单线程池
		for (int i = 0; i < 10; i++) {
			//Thread.sleep(200);
			int x = i;
			service.submit(() ->{
				System.out.println(Thread.currentThread().getName() +" ,"+ x);
			});
		}
		service.shutdown();//关闭线程池
	}
	
	public static void test3() {
		//现在创建一个模拟线程池  但是里面没有线程
		ExecutorService service = Executors.newFixedThreadPool(3);//指定大小线程池
		for (int i = 0; i < 10; i++) {
			//Thread.sleep(200);
			int x = i;
			service.submit(() ->{
				System.out.println(Thread.currentThread().getName() +" ,"+ x);
			});
		}
		service.shutdown();//关闭线程池
	}
	
	public static void test4() {
		//现在创建一个模拟线程池  但是里面没有线程
		ScheduledExecutorService service = Executors.newScheduledThreadPool(3);//定时调度池 可以定时 可以调的大小
		for (int i = 0; i < 10; i++) {
			int x = i;
			service.scheduleAtFixedRate(() ->{
				System.out.println(Thread.currentThread().getName() +" ,"+ x);
			}, 3, 2, TimeUnit.SECONDS);//第一个参数是Runnable 第四个参数是以什么时间为单位  第二个参数表示几秒后开始   第三个参数表示每几秒秒重复一次
		}
	}
}
