package com.tl666.thread;
/**
 * 模拟死锁
 * @author 19760
 *
 */
public class ThreadTest7 implements Runnable{
		private static Pen pen = new Pen();
		private static Note note = new Note();
	public static void main(String[] args) {
			new ThreadTest7(); 
	}
	public ThreadTest7() {
		new Thread(this).start();
		pen.getNote(note);
	}
	@Override
	public void run() {
		note.getPen(pen);
	}
}
class Pen{
	public synchronized void getNote(Note note) {
		System.out.println("我为了得到那个本子");
		note.use();
	}
	public synchronized void use() {
		System.out.println("我写字要用笔");
	}
}
class Note{
	public synchronized void getPen(Pen pen) {
		System.out.println("我为了得到那只笔");
		pen.use();
	}
	public synchronized void use() {
		System.out.println("我要本子用来上厕所");
	}
}