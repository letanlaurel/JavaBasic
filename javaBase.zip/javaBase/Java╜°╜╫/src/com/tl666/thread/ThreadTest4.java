package com.tl666.thread;
/**
 * 	重点类 ThreadLocal 类!!!!!!!!!!!!!!!!!!!!!!!!!
 * 	查api文档
 */
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

public class ThreadTest4 {

	public static void main(String[] args) throws Exception {
		Mysthread mysthread = new Mysthread();
		FutureTask<String> ft = new FutureTask<String>(mysthread);
		FutureTask<String> ft2 = new FutureTask<String>(mysthread);
		FutureTask<String> ft3 = new FutureTask<String>(mysthread);
			new Thread(ft , "张三").start();
			new Thread(ft2 , "李四").start();
			new Thread(ft3 , "王五").start();
			System.out.println(ft.get());
	}

}
class Mysthread implements Callable<String>{
	static int piao = 10;
	@Override
	public String call() throws Exception {
		for (int i = 0; i < 10; i++) {
			if(piao>0) {
				System.out.println(Thread.currentThread().getName()+"卖票"+piao--);
			}
		}
		return "票卖完了";
	}
	
}
