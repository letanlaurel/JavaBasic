package com.tl666.thread;

public class ThreadTest6 {

	public static void main(String[] args) {
		Mythreadss mt = new Mythreadss();
		Thread t1 = new Thread(mt);
		Thread t2 = new Thread(mt);
		Thread t3 = new Thread(mt);
		t1.setPriority(Thread.MIN_PRIORITY);
		t1.start();
		t2.start();
		t3.start();
	}

}
/**
 * 不同步  票出现负数
 * 给程序加锁
 * 1. 同步代码块
 * 2.同步方法
 * 注意 要想数据完整就加同步 ，但同步加多了 可能会出现死锁问题！！！！
 * @author 19760
 *
 */
class Mythreads implements Runnable{
	private int piao = 1000;
	@Override
	public void run() {
		synchronized (this) {//同步代码块
			for (int i = 0; i < 2000; i++) {
			if(piao>0) {
			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName()+"卖票"+piao--);
			}
		}
	  }
	}
}
class Mythreadss implements Runnable{
	private int piao = 1000;
	public synchronized void sale() {//同步方法
			if(piao>0) {
			try {
				Thread.sleep(20);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName()+"卖票"+piao--);
			}
	}
	@Override
	public void run() {
		for (int i = 0; i < 2000; i++) {
			this.sale();
		}
		
	}
}