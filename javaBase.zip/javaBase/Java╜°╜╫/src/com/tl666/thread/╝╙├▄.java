package com.tl666.thread;

import java.util.Base64;
/**
 * 	建议加密匙后加密 或者多次加密
 * @author 19760
 *
 */
public class 加密 {

	public static void main(String[] args) {
		String str = "乐歌歌";//要加密的字符串
		String b = Base64.getEncoder().encodeToString(str.getBytes());//进行加密
		System.out.println("加密后"+b);
		byte [] c = Base64.getDecoder().decode(b);//进行解密
		System.out.println("解密后"+new String(c));
	}

}
