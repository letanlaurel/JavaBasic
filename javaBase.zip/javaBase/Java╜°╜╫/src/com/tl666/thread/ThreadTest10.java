package com.tl666.thread;

public class ThreadTest10 {
	public static void main(String[] args) {
		Data d = new Data();
		new Thread(new Shengcan(d)).start();
		new Thread(new Xiaofei(d)).start();
	}
}

/**
 * 存放数据
 * 
 * @author 19760
 *
 */
class Data {
	private String name;
	private String say;
	boolean flag = true;
	public synchronized void set(String name, String say) {
		if(flag == false) {
			try {
				super.wait();//等待 和sleep的区别是  sleep 到时间了自动唤醒  而wait必须要notify 或者notifyAll唤醒
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		this.name = name;
		try {
			Thread.sleep(50);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		this.say = say;
		flag = false;
		super.notify();
	}

	public synchronized void get() {
		if(flag == true) {
			try {
				super.wait();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		try {
			Thread.sleep(100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(this.name+" = "+this.say);
		flag = true;
		super.notify();
	}
}

/**
 * 生产数据 乐哥哥 帅比 张三 丑逼
 * 
 * @author 19760
 *
 */
class Shengcan implements Runnable {
	private Data d;

	public Shengcan(Data d) {
		this.d = d;
	}

	@Override
	public void run() {
		for (int i = 0; i < 50; i++) {
			if (i % 2 == 0) {
				this.d.set("乐歌歌", "帅比");
			} else {
				this.d.set("张三", "丑比");
			}
		}
	}
}

/**
 * 	消费数据
 * @author 19760
 *
 */
class Xiaofei implements Runnable{
	private Data d;
	public Xiaofei(Data d) {
		this.d = d;
	}
	@Override
	public void run() {
		for (int i = 0; i < 50; i++) {
			this.d.get();
		}
	}
	
}