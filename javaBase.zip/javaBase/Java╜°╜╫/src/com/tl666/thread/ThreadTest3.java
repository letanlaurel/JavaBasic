﻿package com.tl666.thread;

public class ThreadTest3 {

	public static void main(String[] args) {
		MThread mt = new MThread();
		new Thread(mt).start();
		new Thread(mt).start();
		new Thread(mt).start();

	}

}
class MThread implements Runnable{
	public static int piao = 10;
	@Override
	public void run() {
		for (int i = 0; i < 15; i++) {
			if(piao > 0) {
				System.out.println("卖票"+piao--);
			}
		}
	}
	
}
