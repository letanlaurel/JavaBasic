package com.tl666.FS;

import java.lang.reflect.Constructor;

/**
 * 获取构造器
 * @author 19760
 *
 */
class User{
	public User() {
		System.out.println("调用构造器成功！");
	}
	public User(String name ,int age) {
		System.out.println("调用构造器成功："+name+","+age);
	}
	@SuppressWarnings("unused")
	private User(int age) {
		System.out.println("调用私有构造器成功："+age);
	}
}
public class GetConstructorDmeo {

	public static void main(String[] args) throws Exception {
		Class<User> class1 = User.class;
		Constructor<?>[] cts = class1.getConstructors();//只能获取public修饰的所有构造器
		for (Constructor<?> ct : cts) {
			System.out.println(ct);
		}
		System.out.println("--------------------------");
		Constructor<?>[] cts2 = class1.getDeclaredConstructors();//获取所有的构造器
		for (Constructor<?> ct : cts2) {
			System.out.println(ct);
		}
		System.out.println("--------------------------");
		Constructor<User> ct3 = class1.getConstructor(String.class , int.class);//只能获取public修饰的一个构造器
		System.out.println(ct3);
		Constructor<User> ct4 = class1.getDeclaredConstructor(int.class);//获取指定参数列表的一个构造器参数：为参数的字节码
		System.out.println(ct4);
		//ct4.newInstance();//private修饰的调用会报异常
		//但是老子偏要调用private修饰的方法
		//设置java安全检查  可查api文档 中的accessbleObject
		ct4.setAccessible(true);
		ct4.newInstance(233333333);
		ct3.newInstance("张三" , 20);
		//User user = User.class.newInstance();//等价于 == User user = new User();

	}

}
