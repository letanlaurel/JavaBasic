package com.tl666.FS;

import java.lang.reflect.Field;
class Cat{
	private String name = "小白";
	private int age = 5;
	public Cat() {}
	public Cat(String name , int age) {
		this.name = name;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Cat [name=" + name + ", age=" + age + "]";
	}
	
}
public class GetFieldDemo {

	public static void main(String[] args) throws Exception{
		Class<Cat> clazz = Cat.class;
		Field[] fields = clazz.getFields();//获取public修饰的字段 包括继承
		for (Field field : fields) {
			System.out.println(field);
		}
		System.out.println("----------------------------");
		 fields = clazz.getDeclaredFields();//获取所有字段 不包括继承
		for (Field field : fields) {
			System.out.println(field);
		}
		Cat cat = clazz.newInstance();
		Field.setAccessible(fields, true);
		for (Field field : fields) {
			System.out.println(field.get(cat));
			//field.set(cat, 5);
			System.out.println(field);
		}
		
	}
}
