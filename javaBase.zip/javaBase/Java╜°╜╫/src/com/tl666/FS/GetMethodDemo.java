package com.tl666.FS;

import java.lang.reflect.Method;
import java.util.Arrays;

import org.junit.Test;

/**
 * 通过反射获取并调用方法
 * @author 19760
 *
 */
class Person {
	public Person() {
		System.out.println("调用构造器成功！");
	}

	public Person(String name, int age) {
		System.out.println("调用构造器成功：" + name + "," + age);
	}

	@SuppressWarnings("unused")
	private Person(int age) {
		System.out.println("调用私有构造器成功：" + age);
	}

	public void test1() {
		System.out.println("test"+1);
	}

	public void test2(int a) {
		System.out.println(a);
	}

	@SuppressWarnings("unused")
	private void test3(int a,String b) {
		System.out.println(a+", "+b);
	}
	public static int test4(int a) {
		return a;
	}
	public static void test5(int... a) {
		System.out.println(Arrays.toString(a));
	}
	public static void test6(String... a) {
		System.out.println(Arrays.toString(a));
	}
}
/**
 * 获取字段和获取方法类似
 * @author 19760
 *
 */
public class GetMethodDemo {

	public static void main(String[] args) throws Exception {
		Class<Person> class1 = Person.class;
		Method[] methods = class1.getMethods();//获取该类所以的public修饰的方法 包括继承类的public方法
		for (Method method : methods) {
			System.out.println(method);
		}
		System.out.println("---------------------------");
		Method[] methods2 = class1.getDeclaredMethods();//获取该类的所有方法无视访问修饰符 不包括继承类
		for (Method method : methods2) {
			System.out.println(method);
		}
		System.out.println("--------------------------------");
		Method method = class1.getMethod("test2", int.class);//获取该类的一个指定的方法 第一个参数为方法名
		System.out.println(method);
		System.out.println("--------------------------------");
		method = class1.getDeclaredMethod("test3", int.class , String.class);
		System.out.println(method);
		System.out.println("=====================================================================");
		method.setAccessible(true);
		method.invoke(class1.newInstance(), 19 , "李四");
	}
	@Test
	public void test() throws Exception {
		//调用静态的方法
		Class<Person> class1 = Person.class;
		Method method = class1.getDeclaredMethod("test4",int.class);
		System.out.println(method.invoke(null,23333));
		//调用不定参数方法
		method = class1.getMethod("test5", int[].class);
	//	method.invoke(null, 1,2,3,5,4);//错误
		method.invoke(null, new int[] {1,2,3,5,4});//封装一个数组传过去
		System.out.println("--------------------------------------------------------------------");
		method = class1.getDeclaredMethod("test6", String[].class);
		method.invoke(null, new Object[] { new String[]{"132","1234"}});//传递过程中会自动解包  所以传入是加一层封装
		
	}
}



















