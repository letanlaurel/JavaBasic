package com.tl666.FS;

import java.util.Date;

import com.tl666.fx.Demo;

public class ClassInstanceDemo {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws ClassNotFoundException {
		//获取字节码的三种方式
//		第一种方式  类名.class
		Class<Demo> class1 = Demo.class;
		System.out.println(class1);
		//第二种方式  Class.forName();
		Class<?> class2 = Class.forName("com.tl666.fx.Demo");//必须传全类名（加上包名）也就是类的权限定名
		System.out.println(class2);
		//第三种方式 编译类型.上getClass();  就是多态   通过编译类型获取运行类型的字节码
		Object obj = new Date();
		Class<? extends Object> class3 = obj.getClass();//? extends Object 表示 这个类的上限是Object，意思是Object本身 或者Object的子类
		System.out.println(class3);
		System.out.println("----------------------------------");
		System.out.println(class1 == class2);//一个类只能有一份字节码
		System.out.println(class2 == class3);
		System.out.println(class1 == class3);
		/**
		 * 所以的数据类型都有class属性
		 * 基本8大基本数据类型的Class 实列
		 * 只有void关键字才用class属性
		 * byte short int long char float double Boolean void关键字
		 */
		System.out.println("-------------------------------------");
			Class<Integer> class4 = int.class;
			Class<Short> class5 = short.class;
			Class<Void> class6 = void.class;
			//等等
			String [] a = {"a","b"};
			String [] b = {};
			String[][] c = {};
			int [] d = {};
			System.out.println(String[].class == a.getClass());
			System.out.println(b.getClass() == a.getClass());
			//System.out.println(d.getClass() == a.getClass());false
			//System.out.println(c.getClass() == a.getClass());不相等
	}

}
