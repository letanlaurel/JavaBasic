package com.tl666.fx;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

class student<T>{
	private T name;
	private T age;
	
	public student(T name, T age) {
		super();
		this.name = name;
		this.age = age;
	}
	public T getName() {
		return name;
	}
	public void setName(T name) {
		this.name = name;
	}
	public T getAge() {
		return age;
	}
	public void setAge(T age) {
		this.age = age;
	}
	@Override
	public String toString() {
		return "student [name=" + name + ", age=" + age + "]";
	}
}
public class Demo {
	public static void main(String[] args) {
		List<student<?>> list = new ArrayList<>();
		list.add(new student<>("张三",20));
		list.add(new student<>("李四",20));
		list.add(new student<>("王五",20));
//		for (student<?> student : list) {
//			System.out.println(student);
//		}
//		System.out.println("-----------------------------------");
		List<student<?>> list2 = new ArrayList<>();
		list2.add(new student<>("赵柳",17));
		list2.add(new student<>("胡巧琴",22));
		list2.add(new student<>("李明",20));
//		for (student<?> student : list2) {
//			System.out.println(student);
//		}
//		System.out.println("-----------------------------------");
		List<List<student<?>>> class1 = new ArrayList<>();
		class1.add(list);
		class1.add(list2);
		for (List<student<?>> list3 : class1) {
			for (student<?> stu : list3) {
				System.out.println(stu);
			}
		}
		System.out.println("-----------------------------------");
		Iterator<List<student<?>>> iterator = class1.iterator();
		while(iterator.hasNext()) {
			List<student<?>> next = iterator.next();
			Iterator<student<?>> it2 = next.iterator();
			while(it2.hasNext()) {
				System.out.println(it2.next());
			}
		}
	}
}
