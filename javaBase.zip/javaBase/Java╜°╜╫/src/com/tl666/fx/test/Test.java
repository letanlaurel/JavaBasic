package com.tl666.fx.test;


import java.util.Arrays;

import com.tl666.fx.utils.BeanFactory;

public class Test {

	@SuppressWarnings("static-access")
	public static void main(String[] args) throws Exception {
		Arrays a = BeanFactory.INSTANCE.createInstance("java.util.Arrays" ,Arrays.class);
		String [] str = new String[] {"com","tl666","fanshe"};
		System.out.println(a.toString(str));
	}

}
