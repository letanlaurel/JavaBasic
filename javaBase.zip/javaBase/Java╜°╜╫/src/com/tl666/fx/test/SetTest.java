package com.tl666.fx.test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Random;
import java.util.Set;

import org.junit.Test;

public class SetTest {
	/**
	 * 生成10个1-50不重复的随机数
	 * 
	 * @author 19760
	 *
	 */
	@Test
	public void test1() {
		Random random = new Random();
		Set<Integer> set = new HashSet<>();
		while (set.size() < 10) {
			set.add(random.nextInt(50) + 1);
		}
		System.out.println(set);
	}
	/**
	 * 去掉字符串中重复的字符并保持原来的次序
	 */
	@Test
	public void test2() {
//		String str = "aaabbbccc";
		String str2 = "aabddcbcca";
//		char[] array = str.toCharArray();
		char[] array2 = str2.toCharArray();
		Set<Character> set = new LinkedHashSet<>();
		for (char s : array2) {
			set.add(s);
		}
		System.out.println(Arrays.toString(set.toArray()));
		Iterator<Character> iterator = set.iterator();
		StringBuffer sb = new StringBuffer();
		while(iterator.hasNext()) {
			sb.append(iterator.next());
		}
		System.out.println(sb);
	}

}
