package com.tl666.fx.test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
/**
 * map的遍历
 * @author 19760
 *
 */
public class MapTest {

	public static void main(String[] args) {
		Map<String , Integer> map = new HashMap<>();
		map.put("aaa",123);
		map.put("bbb",132);
		map.put("ccc",143);
		map.put("ddd",129);
		for (String str: map.keySet()) {
			System.out.println(str+" = "+map.get(str));
		}
		System.out.println("------------------------------");
		Iterator<String> iterator = map.keySet().iterator();
		while(iterator.hasNext()) {
			String str = iterator.next();
			System.out.println(str+" = "+map.get(str));
		}
		System.out.println("------------------------------");
		Set<Entry<String, Integer>> set = map.entrySet();
		for (Entry<String, Integer> entry : set) {
			//System.out.println(entry);
			System.out.println(entry.getKey()+" = "+entry.getValue());
		}
		System.out.println("------------------------------");
		Iterator<Entry<String, Integer>> iterator2 = map.entrySet().iterator();
		while(iterator2.hasNext()) {
			//System.out.println(iterator2.next());
			Entry<String, Integer> entry = iterator2.next();
			System.out.println(entry.getKey()+" = "+entry.getValue());
		}
		

	}

}
