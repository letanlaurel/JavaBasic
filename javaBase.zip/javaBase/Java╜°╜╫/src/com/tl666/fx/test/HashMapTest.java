package com.tl666.fx.test;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

/**
 * 给你一个字符串 统计每个字符在字符串中出现的次数
 * @author 19760
 *
 */
public class HashMapTest {

	public static void main(String[] args) {
		String str = new String("aabbabababasbawgawgawgaswagawgawgagsgw");
		String str2 = "aaaavvvvbbbbaaaassssnbnnnnkkkkk";
		System.out.println("str:"+test(str));
		System.out.println("str2:"+test(str2));
		//System.out.println(test2());
	}
	static Map<?,?> test(String str) {
		char[] cs = str.toCharArray();
		Map<Character, Integer> map = new HashMap<>();
		for (char c : cs) {
			if(map.containsKey(c)) {
				map.put(c, map.get(c)+1);
			}else {
				map.put(c, 1);
			}
		}
		return map;
	}
	static Map<?,?> test2(){
		Map<?, ?> map = new Hashtable<>();
		//map.put(null, 0);
		//Hashtable不能存null HashMap能存
		//Hashtable线程安全 HashMap线程不安全
		//Hashtable效率低 HashMap效率高
		//Hashtable与HashMap就类似于ArrayList与vector
		return map;
	}
}
