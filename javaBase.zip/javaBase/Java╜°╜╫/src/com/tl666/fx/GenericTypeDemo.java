package com.tl666.fx;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Map;

class XXOO{
	@SuppressWarnings("unused")
	private Map<String , Object> map;
}
/**
 * 	获取字段的类型
 * @author 19760
 *
 */
public class GenericTypeDemo {

	public static void main(String[] args) throws Exception {
		Class<XXOO> clazz = XXOO.class;
		Field field = clazz.getDeclaredField("map");
		field.setAccessible(true);
		System.out.println(field);
		Class<?> type = field.getType();//得到字段的类型 得不到泛型
		System.out.println(type);
		System.out.println(field.getGenericType());
		/**
		 * 	获取泛型的类型
		 */
		Type genericType = field.getGenericType();
		ParameterizedType type3	= (ParameterizedType)genericType;
		Type[] types = type3.getActualTypeArguments();
		for (Type type2 : types) {
			System.out.println(type2);
		}
				

	}

}
