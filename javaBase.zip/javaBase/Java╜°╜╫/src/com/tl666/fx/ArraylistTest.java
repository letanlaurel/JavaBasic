package com.tl666.fx;

import java.util.ArrayList;
import java.util.List;

public class ArraylistTest {
	static <T> void tesst(T a) {
		System.out.println(a);
	}
	<T> void test(T a) {
		System.out.println(a.toString());
	}
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) {
		tesst(20);
		ArraylistTest li = new ArraylistTest();
		li.test(1231313513);
		List<String> list = new ArrayList<String>();
		list.add("13a13wa1313");
		List list2 = null;
		list2 = list;//泛型的擦除
		list2.add(13213);
		
	}
}
