package com.tl666.fx;
/**
 *	 内部类加泛型
 * @author 19760
 *
 * @param <T>
 */
public class ListTest<T> {
	
	public ListTest(T a , T b) {
		
	}
	class test{
		private T a;
		private T b;
		
		public test(T a, T b) {
			super();
			this.a = a;
			this.b = b;
		}
		public T getA() {
			return a;
		}
		public void setA(T a) {
			this.a = a;
		}
		public T getB() {
			return b;
		}
		public void setB(T b) {
			this.b = b;
		}
		
	}

	public static void main(String[] args) {
		
		ListTest<String> list = new ListTest<String>("10", "20");
		ListTest<String>.test test = list.new test("1", "bb");
		System.out.println(test.getA());
		
		
		
	}

}
