package com.tl666.fx.utils;

import java.lang.reflect.Constructor;
/**
 * 	对象工厂   可进行反射攻击  无视访问修饰符  无视反射攻击  
 * @author 19760
 *
 */
public enum BeanFactory {
	INSTANCE;
	/**
	 * 	给一个类的字节码 就能实例化一个该类的对象  
	 * @param classtype
	 * @return
	 */
	public <T>T createInstance(Class<T> classtype){
		try {
			Constructor<T> constructor = classtype.getDeclaredConstructor();
			constructor.setAccessible(true);
			return constructor.newInstance();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	/**
	 * 	给一个类的全限定名 和 字节码 就能实例化一个该类的对象  
	 * @param classname
	 * @param classtype
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <T>T createInstance(String classname, Class<T> classtype){
		try {
			Class<T> clazz = (Class<T>) Class.forName(classname);
			
			Constructor<T> constructor = clazz.getDeclaredConstructor();
			constructor.setAccessible(true);
			 T t = constructor.newInstance();
			if(!classtype.isInstance(t)) {
				throw new IllegalAccessError("参数不匹配");
			}
			return t;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
