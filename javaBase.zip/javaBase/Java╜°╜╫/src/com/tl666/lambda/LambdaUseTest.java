package com.tl666.lambda;
/**
 * 	方法的引用
 *   引用静态方法  类名称 ：：static 方法名称
 *   引用某个对象的方法     对象的实列 ：： 普通方法名
 *   引用某个特定类的方法      类名  ：：  普通方法
 *   引用构造器    类名  ：： new
 * @author 19760
 *
 */
@FunctionalInterface  //表示该接口必需有抽象方法  且只有一个抽象方法
interface IUtil<P , R>{  //  P 表示输入的类型    R表示返回类型
	public R test(P p);
}
@FunctionalInterface  //表示该接口必需有抽象方法  且只有一个抽象方法
interface IUtil2<R>{  //      R表示返回类型
	public R DXzhuanghuan();
}
@FunctionalInterface  //表示该接口必需有抽象方法  且只有一个抽象方法
interface IUtil3<R , P>{  //   P 表示输入的类型     R表示返回类型
	public R bijiao(P p1 , P p2);
}
@FunctionalInterface  //表示该接口必需有抽象方法  且只有一个抽象方法
interface IUtil4<R , P , S>{  //   P ,S表示输入的类型     R表示返回类型
	public R newInstance(P p1 , S p2);
}
class Person{
	private String name;
	private int age;
	public Person(String name , int age) {
		this.name  =name;
		this.age = age;
	}
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + "]";
	}
	
}
public class LambdaUseTest {
	public static void main(String[] args) {
			IUtil<Integer, String> iu = (a) -> String.valueOf(a);
			System.out.println(iu.test(1234).length());
			System.out.println("---------------------------------------------");//这两种方式等价
			IUtil<Integer, String> i = String::valueOf;//进行方法引用
			String str = i.test(1234);//相当于String.valueOf(1234);
			System.out.println(str.length());
			System.out.println("--------------------------------------------------");
			//对象中的转换
			IUtil2<String> i1 = ()-> "tl".toUpperCase();
			System.out.println(i1.DXzhuanghuan());
			System.out.println("--------------------------------------------------");//这两种方式等价
			IUtil2<String> i2 = "tl"::toUpperCase;
			System.out.println(i2.DXzhuanghuan());
			System.out.println("--------------------------------------------------");
			IUtil3<Integer,String> i3 = (a , b) -> a.compareTo(b);
			System.out.println(i3.bijiao("a", "b"));
			System.out.println("--------------------------------------------------");//这两种方式等价
			IUtil3<Integer,String> i4 = String :: compareTo;
			System.out.println(i4.bijiao("c", "d"));
			System.out.println("--------------------------------------------------");
			IUtil4<Person , String , Integer> i5 = Person :: new ;
			System.out.println(i5.newInstance("张三", 21));
			
	}

}
