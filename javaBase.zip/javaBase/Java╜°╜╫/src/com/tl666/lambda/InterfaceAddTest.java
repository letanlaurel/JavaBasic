package com.tl666.lambda;
/**
 * 	学习笔记
 * @author 1976087502
 *
 */
interface IMessage{//jdk1.8新特性 为了补救而设计的  
	public default void print() {
		System.out.println("我是接口中定义了普通方法");
	}
	public static void  test() {
		System.out.println("我是接口中定义的静态方法，可通过接口名直接调用");
	}
	public void test2();
}
class Message implements IMessage{

	@Override
	public void test2() {
		System.out.println("我是接口的实现类，我实现了接口的方法");		
	}
	
}
public class InterfaceAddTest {

	public static void main(String[] args) {
		//1.使用匿名内部类实现接口中的抽象方法
		IMessage im = new IMessage() {//不是new 一个接口 是new 一个1匿名内部类  因为是匿名  所以类名没有
			@Override
			public void test2() {
				System.out.println("我是通过匿名内部类实现的");
			}
		};
		Message mg = new Message();
		IMessage.test();//通过接口类名直接调用
		im.test2();//通过匿名内部类实现的方法
		im.print();//实现类可以调用接口中的普通方法 
		mg.print();//实现类可以调用接口中的普通方法 
		mg.test2();//实现接口中的抽象方法

	}

}
