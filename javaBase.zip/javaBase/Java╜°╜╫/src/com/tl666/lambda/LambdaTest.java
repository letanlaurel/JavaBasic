package com.tl666.lambda;
@FunctionalInterface  //函数接口注解  接口只能有一个方法 为函数式表编程而生
interface IFunction{
	public void print();
}
@FunctionalInterface  //函数接口注解  接口只能有一个方法 为函数式表编程而生
interface IFunction2{
	public int Add(int a, int b);
}
public class LambdaTest {

	public static void main(String[] args) {
		//使用了函数式编程的使用，目的还是一样的
		// (方法的参数) ->  单行语句;
			IFunction f = () -> System.out.println("1a31tg31a3w13");
			f.print();
			System.out.println("-----------------------------------------");
			//(方法的参数) -> {里面添加多行语句}
			IFunction ic = () -> {
				System.out.println("函数式编程！！！");
				System.out.println("函数式编程！！！");
				System.out.println("函数式编程！！！");
				System.out.println("函数式编程！！！");
				System.out.println("函数式编程！！！");
				System.out.println("函数式编程！！！");
				System.out.println("函数式编程！！！");
			};
			ic.print();
			System.out.println("--------------------------------------------");
			IFunction2 f2 = (a , b) -> a + b;//当语句只有一行时  有返回值不用写return
			System.out.println(f2.Add(1, 2));
			IFunction2 if2 = (a , b) -> {
				System.out.println("函数式编程思想");
				System.out.println("函数式编程思想");
				System.out.println("函数式编程思想");
				System.out.println("函数式编程思想");
				System.out.println("函数式编程思想");
				 return a+b;
			};
			System.out.println(if2.Add(5, 3));
			
	}

}
