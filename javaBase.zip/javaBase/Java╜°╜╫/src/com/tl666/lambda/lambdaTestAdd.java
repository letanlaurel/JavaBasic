package com.tl666.lambda;

import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

/**
 * 	进行复杂的函数式运算  就要用到这类的函数式接口
 * 查看api function
 * @author 19760
 *
 */
public class lambdaTestAdd {

	public static void main(String[] args) {
			Function<Integer, String> fu = String :: valueOf;
			System.out.println(fu.apply(123456));
			
			Supplier<String> su = "tl" :: toUpperCase;
			System.out.println(su.get());
			
			Consumer<String> con = System.out :: println;
			con.accept("tlgege");
			
			Predicate<String>  pd = "123456" :: startsWith;//以某个字符串开头返回true
			System.out.println(pd.test("123"));
			 
	}

}
