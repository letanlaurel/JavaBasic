import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;

public class FileInputStreamTest {
	private static final String path = ".";// 表示当前目录

	public static void main(String[] args) throws Exception {
		fileChooserTest(fileChooser());//直接调用该方法
	}
	/**
	 * 将选择器封装在该方法中
	 * @return 返回一个文件
	 */
	public static File fileChooser() {
		JFileChooser jf = new JFileChooser(path);// 实例化文件选择器
		/*
		 * 设置可选类型 参数有三个 分别为 
		 * •JFileChooser.FILES_ONLY  仅仅选择文件
		 * •JFileChooser.DIRECTORIES_ONLY 仅仅选择目录
		 * •JFileChooser.FILES_AND_DIRECTORIES  既选择文件又选择目录
		 */
		jf.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
		// 设置文件过滤
		jf.setFileFilter(new FileFilter() {// FileFilter 为抽象类
			// 注意：这个不是实例化FileFilter类 ， 这是采用内部类的方式

			@Override
			public String getDescription() {// 显示为指定后缀名的文件
				return ".java";
			}

			@Override
			public boolean accept(File f) {// 判断文件是否已java结尾
				if (f.getName().endsWith("java")) {
					return true;
				} else {
					return false;
				}
			}
		});
		jf.showOpenDialog(null);// 设置打开时的窗口 null表示没有父窗口
		return jf.getSelectedFile(); // 返回得到选择器选择的文件
	}
	public static void fileChooserTest(File file) {
		if (file == null) {
			JOptionPane.showMessageDialog(null, "你已取消选择");// 弹窗提示
			System.exit(0);
		} else {
			System.out.println("当前文件名为：" + file.getName() + "\n绝对路径为：" + file.getAbsolutePath());
			/*
			 * 从jdk1.7开始 try后面就可以跟圆括号并且括号里面的资源会自动调用close();方法 释放资源
			 * 因此不需要在后面加finally释放资源，这省去了很多麻烦
			 */
			try (FileInputStream fileInputStream = new FileInputStream(file);
					InputStream stream = new BufferedInputStream(fileInputStream, 10240);) {
				byte[] b = new byte[(int) file.length()];
				stream.read(b);
				System.out.println(new String(b));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
//	public static void Play(String fileurl) {
//
//		try {
//		AudioInputStream ais = AudioSystem.getAudioInputStream(new File(fileurl));
//		AudioFormat aif = ais.getFormat();System.out.println(aif);
//		final SourceDataLine sdl;
//		DataLine.Info info = new DataLine.Info(SourceDataLine.class, aif);
//		sdl = (SourceDataLine) AudioSystem.getLine(info);
//		sdl.open(aif);
//		sdl.start();
//		FloatControl fc=(FloatControl)sdl.getControl(FloatControl.Type.MASTER_GAIN);
//		//value可以用来设置音量，从0-2.0
//		double value=2;
//		float dB = (float)
//		(Math.log(value==0.0?0.0001:value)/Math.log(10.0)*20.0);
//		fc.setValue(dB);
//		int nByte = 0;
//		int writeByte = 0;
//		final int SIZE=1024*64;
//		byte[] buffer = new byte[SIZE];
//		while (nByte != -1) {
//		nByte = ais.read(buffer, 0, SIZE);
//		sdl.write(buffer, 0, nByte);
//		}
//		sdl.stop();
//
//		} catch (Exception e) {
//		e.printStackTrace();
//		}
//		}
//	public static AudioClip play2(String path) {
//		URL url = null;
//		try {
//		url = new URL("file:" + path);
//		} catch (MalformedURLException e) {
//		}
//		return JApplet.newAudioClip(url);
//	}
}
