
public class ThreadTest3 {

	public static void main(String[] args) {
		MYThread mt = new MYThread();
		new Thread(mt).start();
		new Thread(mt).start();
		new Thread(mt).start();

	}

}
class MYThread implements Runnable{
	public static int piao = 10;
	@Override
	public void run() {
		for (int i = 0; i < 15; i++) {
			if(piao > 0) {
				System.out.println("卖票"+piao--);
			}
		}
	}
	
}
