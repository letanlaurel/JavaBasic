package com.tl666.document.test;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.junit.Test;

public class Dom4jTest {
//	public static void main(String[] args) throws Exception{
//		SAXReader reader = new SAXReader();
//		Document doc = reader.read("src/com/tl666/xml/student.xml");
//		Element e = doc.getRootElement();
//		List<Element> stulist = e.elements("student");
//		for (Element stu : stulist) {
//			String name = stu.elementText("name");
//			String age = stu.elementText("age");
//			String gender = stu.elementText("gender");
//			String id = stu.attributeValue("ID");
//			System.out.println(id);
//			System.out.println(name);
//			System.out.println(age);
//			System.out.println(gender);
//			System.out.println("--------------------------");
//		}
//	}
	@Test
	public void test() throws Exception {
		//1.获取解析器
		SAXReader sr = new SAXReader();
		Document doc = sr.read("src/com/tl666/xml/student.xml");
		//获得根节点
		Element element = doc.getRootElement();
		//添加一个节点
		Element addElement = element.addElement("student");
		//添加这个节点的属性
		Element attribute = addElement.addAttribute("ID", "10231");
		//添加这个节点的子节点
		attribute.addElement("name").setText("王五");
		attribute.addElement("age").setText("22");
		attribute.addElement("gender").setText("男");
		//将上面的操作同步到xml文件中
		OutputFormat format = OutputFormat.createPrettyPrint();
		Writer wr = new OutputStreamWriter(new FileOutputStream("src/com/tl666/xml/student.xml"),"UTF-8");
		XMLWriter xw = new XMLWriter(wr,format);
		xw.write(doc);
		wr.close();
	}

}
