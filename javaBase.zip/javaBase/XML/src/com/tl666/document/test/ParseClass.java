package com.tl666.document.test;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.TransformerFactoryConfigurationError;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
public class ParseClass {

	public static void main(String[] args) throws Exception {
//		 String str = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse("src/com/tl666/xml/student.xml").getElementsByTagName("age").item(0).getTextContent();
//		 System.out.println(str);
		Document doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse("src/com/tl666/xml/student.xml");
		//test(doc);
	//	test2(doc);
		test3(doc);
	}
	/**
	 * 往xml文件中添加节点
	 * @param doc
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 * @throws TransformerFactoryConfigurationError
	 */
	static void test(Document doc) throws TransformerConfigurationException, TransformerException, TransformerFactoryConfigurationError {
		Element element = doc.createElement("stuId");
		element.setTextContent("123456");
		doc.getElementsByTagName("student").item(0).appendChild(element);
		TransformerFactory.newInstance().newTransformer().transform(new DOMSource(doc), new StreamResult("src/com/tl666/xml/student.xml"));
	}
	/**
	 * 往xml文件中删除节点
	 * @param doc
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 * @throws TransformerFactoryConfigurationError
	 */
	static void test2(Document doc) throws TransformerConfigurationException, TransformerException, TransformerFactoryConfigurationError {
		doc.getElementsByTagName("stuId").item(0).getParentNode().removeChild(doc.getElementsByTagName("stuId").item(0));
		//等价写法
//		Node node = doc.getElementsByTagName("stuId").item(0);
//		node.getParentNode().removeChild(node);
		TransformerFactory.newInstance().newTransformer().transform(new DOMSource(doc), new StreamResult("src/com/tl666/xml/student.xml"));
	}
	static void test3(Document doc) throws TransformerConfigurationException, TransformerException, TransformerFactoryConfigurationError {
		//获得节点
		Node nd = doc.getElementsByTagName("student").item(0);
		//强制类型转换
		Element ele = (Element)nd;
		ele.setAttribute("ID", "100111");
		TransformerFactory.newInstance().newTransformer().transform(new DOMSource(doc), new StreamResult("src/com/tl666/xml/student.xml") );
	}
}
