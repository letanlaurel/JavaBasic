package com.tl666.document.test;

import java.io.FileInputStream;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DocumentTest {

	public static void main(String[] args) throws Exception {
		//1.创建一个解析器工厂
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		//2.创建一个解析器
		DocumentBuilder builder = factory.newDocumentBuilder();
		//3.通过解析器获得一个document对象
		Document parse = builder.parse(new FileInputStream("src/com/tl666/xml/student.xml"));
		Trans(parse);
		//4.获取document对象的内容
		NodeList list = parse.getElementsByTagName("name");
		for (int i = 0; i < list.getLength(); i++) {
			Node item = list.item(i);
			System.out.println(item.getTextContent());
		}
	}
	/**
	 * 修改xml指定的内容并且同步到xml文件中
	 * @param doc
	 * @throws Exception
	 */
	static void Trans(Document doc) throws Exception {
		doc.getElementsByTagName("age").item(0).setTextContent("1000");
		TransformerFactory tf = TransformerFactory.newInstance();
		Transformer transformer = tf.newTransformer();
		transformer.transform(new DOMSource(doc), new StreamResult("src/com/tl666/xml/student.xml"));
	} 

}
